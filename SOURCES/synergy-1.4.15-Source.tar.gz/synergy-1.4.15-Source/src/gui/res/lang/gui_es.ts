<?xml version="1.0" encoding="utf-8"?><!DOCTYPE TS><TS language="es" sourcelanguage="en" version="2.0">
<context>
    <name>AboutDialogBase</name>
    <message>
        <location filename="res/AboutDialogBase.ui" line="38"/>
        <source>About Synergy</source>
        <translation type="finished">Acerca de Synergy</translation>
    </message>
    <message utf8="true">
        <location filename="res/AboutDialogBase.ui" line="53"/>
        <source>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Synergy GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (synergy-foss.org).
&lt;/p&gt;</source>
        <oldsource>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Synergy GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (synergy-foss.org).
&lt;/p&gt;</oldsource>
        <translation type="finished">&lt;p&gt;
Aplicación de compartición de teclado y ratón. Plataforma cruzada y código abierto.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy es publicado bajo la Licencia Pública General GNU (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy está basado en CosmoSynergy por Richard Lee y Adam Feder.&lt;br /&gt;
El GUI de Synergy está basado en QSynergy por Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visita nuestro sitio web para ayuda e información (synergy-foss.org).
&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="140"/>
        <source>Unknown</source>
        <translation type="finished">Desconocido</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="124"/>
        <source>Version:</source>
        <translation type="finished">Versión</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="163"/>
        <source>&amp;Ok</source>
        <translation type="finished">&amp;Ok</translation>
    </message>
</context>
<context>
    <name>ActionDialogBase</name>
    <message>
        <location filename="res/ActionDialogBase.ui" line="14"/>
        <source>Configure Action</source>
        <translation type="finished">Configurar Acción</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="20"/>
        <source>Choose the action to perform</source>
        <translation type="finished">Elige la acción a presentar</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="26"/>
        <source>Press a hotkey</source>
        <translation type="finished">Presiona una tecla de acceso directo</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="36"/>
        <source>Release a hotkey</source>
        <translation type="finished">Liberar una tecla de acceso directo</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="43"/>
        <source>Press and release a hotkey</source>
        <translation type="finished">Presionar y liberar una tecla de acceso directo</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="69"/>
        <source>only on these screens</source>
        <translation type="finished">sólo en estas pantallas</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="119"/>
        <source>Switch to screen</source>
        <translation type="finished">Cambiar a pantalla</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="150"/>
        <source>Switch in direction</source>
        <translation type="finished">Cambiar dirección</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="174"/>
        <source>left</source>
        <translation type="finished">izquierda</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="179"/>
        <source>right</source>
        <translation type="finished">derecha</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="184"/>
        <source>up</source>
        <translation type="finished">arriba</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="189"/>
        <source>down</source>
        <translation type="finished">abajo</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="201"/>
        <source>Lock cursor to screen</source>
        <translation type="finished">Bloquear cursor en pantalla</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="225"/>
        <source>toggle</source>
        <translation type="finished">cambiar</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="230"/>
        <source>on</source>
        <translation type="finished">encendido</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="235"/>
        <source>off</source>
        <translation type="finished">apagado</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="248"/>
        <source>This action is performed when</source>
        <translation type="finished">Esta acción se presenta cuando</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="254"/>
        <source>the hotkey is pressed</source>
        <translation type="finished">la tecla de acceso directo es presionada</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="264"/>
        <source>the hotkey is released</source>
        <translation type="finished">la tecla de acceso directo es liberada</translation>
    </message>
</context>
<context>
    <name>HotkeyDialogBase</name>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="14"/>
        <source>Hotkey</source>
        <translation type="finished">Tecla de Acceso Directo</translation>
    </message>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="20"/>
        <source>Enter the specification for the hotkey:</source>
        <translation type="finished">Ingresa la especificación para la tecla de acceso:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="src/MainWindow.cpp" line="642"/>
        <source>&amp;Start</source>
        <translation type="finished">&amp;Iniciar</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="196"/>
        <source>&amp;File</source>
        <translation type="finished">&amp;Archivo</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="197"/>
        <source>&amp;Edit</source>
        <translation type="finished">&amp;Editar</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="198"/>
        <source>&amp;Window</source>
        <translation type="finished">&amp;Ventana</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="199"/>
        <source>&amp;Help</source>
        <translation type="finished">&amp;Ayuda</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="326"/>
        <source>&lt;p&gt;Version %1 is now available, &lt;a href=&quot;%2&quot;&gt;visit website&lt;/a&gt;.&lt;/p&gt;</source>
        <translation type="finished">&lt;p&gt;La versión %1 está disponible, &lt;a href=&quot;%2&quot;&gt;visita el sitio web&lt;/a&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="458"/>
        <source>Program can not be started</source>
        <translation type="finished">El programa no puede iniciar</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="458"/>
        <source>The executable&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;could not be successfully started, although it does exist. Please check if you have sufficient permissions to run this program.</source>
        <translation type="finished">El ejecutable&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;no pudo iniciar exitosamente, aunque sí existe. Por favor, revisa si tienes permisos suficientes para ejecutar este programa.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="477"/>
        <source>Synergy client not found</source>
        <translation type="finished">No se encontró el cliente Synergy</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="478"/>
        <source>The executable for the synergy client does not exist.</source>
        <translation type="finished">El ejecutable para el cliente Synergy no existe.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="485"/>
        <source>Hostname is empty</source>
        <translation type="finished">Nombre de Host está vacío</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="486"/>
        <source>Please fill in a hostname for the synergy client to connect to.</source>
        <translation type="finished">Por favor, ingresa un nombre del host al que se conectará el cliente Synergy.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="511"/>
        <source>Cannot write configuration file</source>
        <translation type="finished">No se puede escribir el archivo de configuración</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="511"/>
        <source>The temporary configuration file required to start synergy can not be written.</source>
        <translation type="finished">El archivo de configuración temporal necesario para iniciar Synergy no puede ser escrito.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="524"/>
        <source>Configuration filename invalid</source>
        <translation type="finished">Nombre de archivo de configuración inválido</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="525"/>
        <source>You have not filled in a valid configuration file for the synergy server. Do you want to browse for the configuration file now?</source>
        <translation type="finished">No has ingresado un archivo de configuración válido para el servidor Synergy. Queres buscar el archivo de configuración ahora?</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="552"/>
        <source>Synergy server not found</source>
        <translation type="finished">No se encontró el servidor Synergy</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="553"/>
        <source>The executable for the synergy server does not exist.</source>
        <translation type="finished">El ejecutable para el servidor Synergy no existe.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="617"/>
        <source>Synergy terminated with an error</source>
        <translation type="finished">Synergy terminó con un error</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="617"/>
        <source>Synergy terminated unexpectedly with an exit code of %1.&lt;br&gt;&lt;br&gt;Please see the log output for details.</source>
        <translation type="finished">Synergu terminó inesperadamente con el código de salida %1.&lt;br&gt;&lt;br&gt;Por favor, vea el registro de eventos para detalles.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="636"/>
        <source>&amp;Stop</source>
        <translation type="finished">&amp;Detener</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="659"/>
        <source>service mode</source>
        <translation type="finished">modo de servicio</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="659"/>
        <source>desktop mode</source>
        <translation type="finished">modo escritorio</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="660"/>
        <source>Synergy is running (%1).</source>
        <translation type="finished">Synergy se está ejecutando (%1).</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="821"/>
        <source>Elevate Synergy</source>
        <translation type="finished">Elevar a Synergy</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="822"/>
        <source>Are you sure you want to elevate Synergy?

This allows Synergy to interact with elevated processes and the UAC dialog, but can cause problems with non-elevated processes. Elevate Synergy only if you really need to.</source>
        <translation type="finished">¿Estás seguro que quieres elevar a Synergy?
Esto permitirá que puedas interactuar con procesos elevados y el cuadro de diálogo de UAC, pero puede causar problemas con procesos no elevados. Eleva a Synergy solo si realmente lo necesitas.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="664"/>
        <source>Synergy is starting.</source>
        <translation type="finished">Synergy está iniciando.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="667"/>
        <source>Synergy is not running.</source>
        <translation type="finished">Synergy no se está ejecutando.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="724"/>
        <source>Unknown</source>
        <translation type="finished">Desconocido</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="762"/>
        <source>Browse for a synergys config file</source>
        <translation type="finished">Buscar un archivo de configuración Synergy</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="775"/>
        <source>Save configuration as...</source>
        <translation type="finished">Guardar configuración como...</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="779"/>
        <source>Save failed</source>
        <translation type="finished">No se guardó</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="779"/>
        <source>Could not save configuration to file.</source>
        <translation type="finished">No se pudo guardar la configuración en el archivo.</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="res/MainWindowBase.ui" line="26"/>
        <source>Synergy</source>
        <translation type="finished">Synergy</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="54"/>
        <source>Screen name:</source>
        <translation type="finished">Nombre en pantalla:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="61"/>
        <source>&amp;Server IP:</source>
        <translation type="finished">IP del servidor:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="160"/>
        <location filename="res/MainWindowBase.ui" line="315"/>
        <source>&amp;Start</source>
        <translation type="finished">&amp;Iniciar</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="187"/>
        <source>&amp;Server (share this computer's mouse and keyboard):</source>
        <translation type="finished">&amp;Servidor (compartir el mouse y teclado de este computador):</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="254"/>
        <source>Use existing configuration:</source>
        <translation type="finished">Usar configuración existente:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="263"/>
        <source>&amp;Configuration file:</source>
        <translation type="finished">&amp;Configuración:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="283"/>
        <source>&amp;Browse...</source>
        <translation type="finished">&amp;Buscar...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="220"/>
        <source>Configure interactively:</source>
        <translation type="finished">Configurar interactivamente:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="232"/>
        <source>&amp;Configure Server...</source>
        <translation type="finished">&amp;Configurar Servidor...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="39"/>
        <source>&amp;Client (use another computer's keyboard and mouse):</source>
        <translation type="finished">&amp;Cliente (usar mouse y teclado de otro computador):</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="84"/>
        <source>Ready</source>
        <translation type="finished">Listo</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="91"/>
        <source>Log</source>
        <translation type="finished">Registro</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="167"/>
        <source>&amp;Apply</source>
        <translation type="finished">Aplicar</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="174"/>
        <source>&amp;Elevate</source>
        <translation type="finished">&amp;Elevar</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="204"/>
        <source>IP addresses:</source>
        <translation type="finished">Direcciones IP:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="296"/>
        <source>&amp;About Synergy...</source>
        <translation type="finished">&amp;Acerca de Synergy...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="304"/>
        <source>&amp;Quit</source>
        <translation type="finished">&amp;Salir</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="307"/>
        <source>Quit</source>
        <translation type="finished">Salir</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="318"/>
        <source>Run</source>
        <translation type="finished">Ejecutar</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="329"/>
        <source>S&amp;top</source>
        <translation type="finished">De&amp;tener</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="332"/>
        <source>Stop</source>
        <translation type="finished">Detener</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="340"/>
        <source>S&amp;how Status</source>
        <translation type="finished">&amp;Mostrar Estado</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="348"/>
        <source>&amp;Hide</source>
        <translation type="finished">&amp;Ocultar</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="351"/>
        <source>Hide</source>
        <translation type="finished">Ocultar</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="359"/>
        <source>&amp;Show</source>
        <translation type="finished">&amp;Mostrar</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="362"/>
        <source>Show</source>
        <translation type="finished">Mostrar</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="370"/>
        <source>Save configuration &amp;as...</source>
        <translation type="finished">Gu&amp;ardar configuración como...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="373"/>
        <source>Save the interactively generated server configuration to a file.</source>
        <translation type="finished">Guardar la configuración generada interactivamente en un archivo.</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="381"/>
        <source>Settings</source>
        <translation type="finished">Opciones</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="384"/>
        <source>Edit settings</source>
        <translation type="finished">Editar Opciones</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="392"/>
        <source>Run Wizard</source>
        <translation type="finished">Iniciar instalación</translation>
    </message>
</context>
<context>
    <name>NewScreenWidget</name>
    <message>
        <location filename="src/NewScreenWidget.cpp" line="32"/>
        <source>Unnamed</source>
        <translation type="finished">Sin nombre</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="src/MainWindow.cpp" line="45"/>
        <source>Synergy Configurations (*.sgc);;All files (*.*)</source>
        <translation type="finished">Configuraciones Synergy (*.sgc);;Todos los archivos (*.*)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="48"/>
        <source>Synergy Configurations (*.conf);;All files (*.*)</source>
        <translation type="finished">Configuraciones Synergy (*.conf);;Todos los archivos (*.*)</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="90"/>
        <source>System tray is unavailable, quitting.</source>
        <translation type="finished">Bandeja de sistema no disponible, saliendo.</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialog</name>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="65"/>
        <source>Screen name is empty</source>
        <translation type="finished">Nombre de pantalla está vacío</translation>
    </message>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="65"/>
        <source>The name for a screen can not be empty. Please fill in a name or cancel the dialog.</source>
        <translation type="finished">El nombre de una pantalla no puede estar vacío. Por favor, ingresa un nombre o cierre la ventana.</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialogBase</name>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="14"/>
        <source>Screen Settings</source>
        <translation type="finished">Opciones de Pantalla</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="22"/>
        <source>Screen &amp;name:</source>
        <translation type="finished">&amp;Nombre de Pantalla</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="42"/>
        <source>A&amp;liases</source>
        <translation type="finished">&amp;Alias</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="57"/>
        <source>&amp;Add</source>
        <translation type="finished">&amp;Agregar</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="74"/>
        <source>&amp;Remove</source>
        <translation type="finished">Elimina&amp;r</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="97"/>
        <source>&amp;Modifier keys</source>
        <translation type="finished">&amp;Modificar teclas</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="106"/>
        <source>&amp;Shift:</source>
        <translation type="finished">&amp;Shift:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="117"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="164"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="211"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="258"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="305"/>
        <source>Shift</source>
        <translation type="finished">Mayúsculas</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="122"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="169"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="216"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="263"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="310"/>
        <source>Ctrl</source>
        <translation type="finished">Ctrl</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="127"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="174"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="221"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="268"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="315"/>
        <source>Alt</source>
        <translation type="finished">Alt</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="132"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="179"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="226"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="273"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="320"/>
        <source>Meta</source>
        <translation type="finished">Meta</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="137"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="184"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="231"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="278"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="325"/>
        <source>Super</source>
        <translation type="finished">Super</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="142"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="189"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="236"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="283"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="330"/>
        <source>None</source>
        <translation type="finished">Ninguno</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="150"/>
        <source>&amp;Ctrl:</source>
        <translation type="finished">&amp;Ctrl:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="197"/>
        <source>Al&amp;t:</source>
        <translation type="finished">Al&amp;t:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="244"/>
        <source>M&amp;eta:</source>
        <translation type="finished">M&amp;eta:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="291"/>
        <source>S&amp;uper:</source>
        <translation type="finished">S&amp;uper:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="358"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">Esquinas &amp;Desactivadas</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="367"/>
        <source>Top-left</source>
        <translation type="finished">Arriba-Izquierda</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="374"/>
        <source>Top-right</source>
        <translation type="finished">Arriba-Derecha</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="381"/>
        <source>Bottom-left</source>
        <translation type="finished">Abajo-Izquierda</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="388"/>
        <source>Bottom-right</source>
        <translation type="finished">Abajo-Derecha</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="397"/>
        <source>Corner Si&amp;ze:</source>
        <translation type="finished">&amp;Tamaño de Esquina:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="428"/>
        <source>&amp;Fixes</source>
        <translation type="finished">&amp;Reparaciones</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="437"/>
        <source>Fix CAPS LOCK key</source>
        <translation type="finished">Reparar tecla CAPS LOCK (BLOQ MAYÚS)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="444"/>
        <source>Fix NUM LOCK key</source>
        <translation type="finished">Reparar tecla NUM LOCK (BLOQ NUM)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="451"/>
        <source>Fix SCROLL LOCK key</source>
        <translation type="finished">Reparar tecla SCROLL LOCK (BLOQ DESPL)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="458"/>
        <source>Fix XTest for Xinerama</source>
        <translation type="finished">Reparar XTest para Xinerama</translation>
    </message>
</context>
<context>
    <name>ScreenSetupModel</name>
    <message>
        <location filename="src/ScreenSetupModel.cpp" line="51"/>
        <source>&lt;center&gt;Screen: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;Double click to edit settings&lt;br&gt;Drag screen to the trashcan to remove it</source>
        <translation type="finished">&lt;center&gt;Pantalla: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;Haz doble clic para editar opciones&lt;br&gt;Arrastra la pantalla a la papelera para borrarla</translation>
    </message>
</context>
<context>
    <name>ServerConfigDialogBase</name>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="13"/>
        <source>Server Configuration</source>
        <translation type="finished">Configuración de Servidor</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="23"/>
        <source>Screens and links</source>
        <translation type="finished">Pantallas y enlaces</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="34"/>
        <source>Drag a screen from the grid to the trashcan to remove it.</source>
        <translation type="finished">Arrastra una pantalla de la matriz a la papelera para borrarla.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="59"/>
        <source>Configure the layout of your synergy server configuration.</source>
        <translation type="finished">Configurar el diseño tu configuración de servidor Synergy.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="72"/>
        <source>Drag this button to the grid to add a new screen.</source>
        <translation type="finished">Arrastra este botón a la matriz para agregar una nueva pantalla.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="127"/>
        <source>Drag new screens to the grid or move existing ones around.
Drag a screen to the trashcan to delete it.
Double click on a screen to edit its settings.</source>
        <translation type="finished">Arrastra nuevas pantallas a la matriz o mueve las existentes.
Arrastra una pantalla a la papelera para eliminarla.
Haz doble clic en una pantalla para editar sus opciones.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="156"/>
        <source>Hotkeys</source>
        <translation type="finished">Teclas de acceso directo</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="162"/>
        <source>&amp;Hotkeys</source>
        <translation type="finished">&amp;Teclas de acceso directo</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="174"/>
        <source>&amp;New</source>
        <translation type="finished">&amp;Nueva</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="184"/>
        <source>&amp;Edit</source>
        <translation type="finished">&amp;Editar</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="194"/>
        <source>&amp;Remove</source>
        <translation type="finished">Elimina&amp;r</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="217"/>
        <source>A&amp;ctions</source>
        <translation type="finished">&amp;Acciones</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="229"/>
        <source>Ne&amp;w</source>
        <translation type="finished">&amp;Nueva</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="239"/>
        <source>E&amp;dit</source>
        <translation type="finished">&amp;Editar</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="249"/>
        <source>Re&amp;move</source>
        <translation type="finished">&amp;Borrar</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="273"/>
        <source>Advanced server settings</source>
        <translation type="finished">Opciones Avanzadas de Servidor</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="279"/>
        <source>&amp;Switch</source>
        <translation type="finished">&amp;Cambiar</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="290"/>
        <source>Switch &amp;after waiting</source>
        <translation type="finished">Cambiar &amp;al esperar</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="329"/>
        <location filename="res/ServerConfigDialogBase.ui" line="382"/>
        <location filename="res/ServerConfigDialogBase.ui" line="457"/>
        <source>ms</source>
        <translation type="finished">ms</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="343"/>
        <source>Switch on double &amp;tap within</source>
        <translation type="finished">Cambiar doble toque en</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="407"/>
        <source>&amp;Options</source>
        <translation type="finished">Opciones</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="418"/>
        <source>&amp;Check clients every</source>
        <translation type="finished">Revisar &amp;clientes cada</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="469"/>
        <source>Use &amp;relative mouse moves</source>
        <translation type="finished">&amp;Sar movimientos &amp;relativos del mouse</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="479"/>
        <source>S&amp;ynchronize screen savers</source>
        <translation type="finished">&amp;Sincronizar protectores de pantalla</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="489"/>
        <source>Don't take &amp;foreground window on Windows servers</source>
        <translation type="finished">No tomar la ventana de primer plano en servidores Windows</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="512"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">Esquinas &amp;Desactivadas</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="521"/>
        <source>To&amp;p-left</source>
        <translation type="finished">&amp;Arriba-Izquierda</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="528"/>
        <source>Top-rig&amp;ht</source>
        <translation type="finished">&amp;Arriba-Derec&amp;ha</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="535"/>
        <source>&amp;Bottom-left</source>
        <translation type="finished">&amp;Bajo-Izquierda</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="542"/>
        <source>Bottom-ri&amp;ght</source>
        <translation type="finished">&amp;Abajo-Derecha</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="564"/>
        <source>Cor&amp;ner Size:</source>
        <translation type="finished">&amp;Tamaño de Esqui&amp;na:</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="src/SettingsDialog.cpp" line="62"/>
        <source>Encryption password must not be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/SettingsDialog.cpp" line="121"/>
        <source>Save log file to...</source>
        <translation type="finished">Guardar archivo de registro en...</translation>
    </message>
</context>
<context>
    <name>SettingsDialogBase</name>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="14"/>
        <source>Settings</source>
        <translation type="finished">Opciones</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="165"/>
        <source>&amp;Advanced</source>
        <translation type="finished">&amp;Avanzado</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="177"/>
        <source>Sc&amp;reen name:</source>
        <translation type="finished">&amp;Nomb&amp;re de Pantalla:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="194"/>
        <source>P&amp;ort:</source>
        <translation type="finished">Puert&amp;o:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="223"/>
        <source>&amp;Interface:</source>
        <translation type="finished">&amp;Interfaz:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="26"/>
        <source>&amp;Start Synergy after logging in</source>
        <translation type="finished">Iniciar Synergy luego de autenticarte</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="33"/>
        <source>&amp;Automatically start server/client</source>
        <translation type="finished">Iniciar &amp;automáticamente servidor/cliente</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="40"/>
        <source>&amp;Hide when server/client starts</source>
        <translation type="finished">&amp;Ocultar al iniciar servidor/cliente</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="273"/>
        <source>Logging</source>
        <translation type="finished">Registro</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="240"/>
        <source>&amp;Process mode:</source>
        <translation type="finished">Modo de &amp;proceso:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="251"/>
        <source>Service</source>
        <translation type="finished">Servicio</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="256"/>
        <source>Desktop (legacy)</source>
        <translation type="finished">Escritorio (legacy)</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="291"/>
        <source>&amp;Logging level:</source>
        <translation type="finished">Nive&amp;l de Registro:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="340"/>
        <source>Log to file:</source>
        <translation type="finished">Guardar registro en archivo:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="357"/>
        <source>Browse...</source>
        <translation type="finished">Examinar...</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="302"/>
        <source>Error</source>
        <translation type="finished">Error</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="20"/>
        <source>&amp;Graphical interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="55"/>
        <source>&amp;Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="82"/>
        <source>&amp;Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="97"/>
        <source>&amp;Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="142"/>
        <source>Pass&amp;word:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="307"/>
        <source>Warning</source>
        <translation type="finished">Advertencia</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="312"/>
        <source>Note</source>
        <translation type="finished">Nota</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="317"/>
        <source>Info</source>
        <translation type="finished">Información</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="322"/>
        <source>Debug</source>
        <translation type="finished">Depuración</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="327"/>
        <source>Debug1</source>
        <translation type="finished">Depuración1</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="332"/>
        <source>Debug2</source>
        <translation type="finished">Depuración2</translation>
    </message>
</context>
<context>
    <name>SetupWizard</name>
    <message>
        <location filename="src/SetupWizard.cpp" line="64"/>
        <source>Setup Synergy</source>
        <translation type="finished">Configurar Synergy</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="74"/>
        <source>Please select an option.</source>
        <translation type="finished">Elige una opción, por favor.</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="84"/>
        <source>Encryption mode required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="93"/>
        <source>Encryption password required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="100"/>
        <source>Encryption password and confirmation do not match.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetupWizardBase</name>
    <message>
        <location filename="res/SetupWizardBase.ui" line="20"/>
        <source>Setup Synergy</source>
        <translation type="finished">Configurar Synergy</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="24"/>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="33"/>
        <source>Thanks for installing Synergy!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="108"/>
        <source>Synergy lets you easily share your mouse and keyboard between multiple computers on your desk, and it's Free and Open Source. Just move your mouse off the edge of one computer's screen on to another. You can even share all of your clipboards. All you need is a network connection. Synergy is cross-platform (works on Windows, Mac OS X and Linux).</source>
        <translation type="finished">Synergy te permite compartir fácilmente tu mouse y teclado entre múltiples computadores en tu escritorio, es Gratis y es de Código Abierto. Solo mueve tu mouse hacia los bordes de la pantalla de uno de los computadores hacia otro. Puedes incluso compartir tu portapapeles. Todo lo que necesitas es una conexión de red. Synergy es multiplataforma (funciona en Windows, Mac OS X y Linux).</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="125"/>
        <source>Server or Client?</source>
        <translation type="finished">¿Servidor o Cliente?</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="140"/>
        <source>&amp;Server (new setup)</source>
        <translation type="finished">Servidor (nueva configuracion)</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="153"/>
        <source>This is the first computer you are configuring. Your keyboard and mouse are connected to this computer. This will allow you to move your mouse over to another computer's screen. There can only be one server in your setup.</source>
        <translation type="finished">Este es el primer ordenador que configuras. Tu teclado y ratón están conectados a este ordenador. Esto te permitirá mover tu ratón de la pantalla de un ordenador a la del otro. Solo puede haber un servidor en tus ajustes.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="185"/>
        <source>&amp;Client (add to setup)</source>
        <translation type="finished">Cliente (agregar para configurar)</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="198"/>
        <source>You have already set up a server. This is a computer you wish to control using the server's keyboard and mouse. There can be many clients in your setup.</source>
        <oldsource>You have already set up a server. This a computer you wish to control using the server's keyboard and mouse. There can be many clients in your setup.</oldsource>
        <translation type="finished">Ya haz configurado un servidor. Esta es una computadora que quieres controlar utilizando el teclado y ratón del servidor. Pueden existir varios clientes en tu configuración.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="231"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="237"/>
        <source>Network traffic can be easily monitored. Using encryption can reduce the risk that sensitive information will be revealed to others (for example, passwords).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="263"/>
        <source>Choose a random encryption mode. The mode must be the same on both the client and server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="308"/>
        <source>&amp;Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="391"/>
        <source>A longer password will provide stronger encryption. It is a good idea to use 20 characters or more.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="415"/>
        <source>&amp;Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="474"/>
        <source>&amp;Confirm:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VersionChecker</name>
    <message>
        <location filename="src/VersionChecker.cpp" line="102"/>
        <source>Unknown</source>
        <translation type="finished">Desconocido</translation>
    </message>
</context>
</TS>