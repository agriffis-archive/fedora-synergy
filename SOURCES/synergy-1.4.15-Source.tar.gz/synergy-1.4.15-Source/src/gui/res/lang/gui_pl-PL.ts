<?xml version="1.0" encoding="utf-8"?><!DOCTYPE TS><TS language="pl-PL" sourcelanguage="en" version="2.0">
<context>
    <name>AboutDialogBase</name>
    <message>
        <location filename="res/AboutDialogBase.ui" line="38"/>
        <source>About Synergy</source>
        <translation type="finished">O Synergy</translation>
    </message>
    <message utf8="true">
        <location filename="res/AboutDialogBase.ui" line="53"/>
        <source>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Synergy GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (synergy-foss.org).
&lt;/p&gt;</source>
        <oldsource>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Synergy GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (synergy-foss.org).
&lt;/p&gt;</oldsource>
        <translation type="finished">&lt;p&gt;
Aplikacja współdzieląca klawiaturę i mysz, tworzona na zasadach wolnego oprogramowania, wieloplatformowa.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy jest rozwijany na zasadach wolnego oprogramowania GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Synergy GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Strona domowa i pomoc na stronie WWW (synergy-foss.org).
&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="140"/>
        <source>Unknown</source>
        <translation type="finished">Nieznane</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="124"/>
        <source>Version:</source>
        <translation type="finished">Wersja:</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="163"/>
        <source>&amp;Ok</source>
        <translation type="finished">&amp;Ok</translation>
    </message>
</context>
<context>
    <name>ActionDialogBase</name>
    <message>
        <location filename="res/ActionDialogBase.ui" line="14"/>
        <source>Configure Action</source>
        <translation type="finished">Konfiguruj akcje</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="20"/>
        <source>Choose the action to perform</source>
        <translation type="finished">Wybierz akcję do wykonania</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="26"/>
        <source>Press a hotkey</source>
        <translation type="finished">Wciśnij klawisz</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="36"/>
        <source>Release a hotkey</source>
        <translation type="finished">Zwolnij klawisz</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="43"/>
        <source>Press and release a hotkey</source>
        <translation type="finished">Wciśnij i zwolnij klawisz</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="69"/>
        <source>only on these screens</source>
        <translation type="finished">tylko na tych ekranach</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="119"/>
        <source>Switch to screen</source>
        <translation type="finished">Przejdź do ekranu</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="150"/>
        <source>Switch in direction</source>
        <translation type="finished">Przełącz w kierunku</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="174"/>
        <source>left</source>
        <translation type="finished">w lewo</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="179"/>
        <source>right</source>
        <translation type="finished">w prawo</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="184"/>
        <source>up</source>
        <translation type="finished">w górę</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="189"/>
        <source>down</source>
        <translation type="finished">w dół</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="201"/>
        <source>Lock cursor to screen</source>
        <translation type="finished">Zablokuj kursor myszki dla danego ekranu</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="225"/>
        <source>toggle</source>
        <translation type="finished">przełącz</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="230"/>
        <source>on</source>
        <translation type="finished">wł.</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="235"/>
        <source>off</source>
        <translation type="finished">wył.</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="248"/>
        <source>This action is performed when</source>
        <translation type="finished">Ta akcja jest wykonywana gdy</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="254"/>
        <source>the hotkey is pressed</source>
        <translation type="finished">klawisz skrótu jest wciśnięty</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="264"/>
        <source>the hotkey is released</source>
        <translation type="finished">klawisz skrótu jest zwolniony</translation>
    </message>
</context>
<context>
    <name>HotkeyDialogBase</name>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="14"/>
        <source>Hotkey</source>
        <translation type="finished">Klawisz skrótu</translation>
    </message>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="20"/>
        <source>Enter the specification for the hotkey:</source>
        <translation type="finished">Wprowadź opis dla skrótu klawiszowego:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="src/MainWindow.cpp" line="642"/>
        <source>&amp;Start</source>
        <translation type="finished">Start</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="196"/>
        <source>&amp;File</source>
        <translation type="finished">Plik</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="197"/>
        <source>&amp;Edit</source>
        <translation type="finished">Edytuj</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="198"/>
        <source>&amp;Window</source>
        <translation type="finished">Okno</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="199"/>
        <source>&amp;Help</source>
        <translation type="finished">&amp;Pomoc</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="326"/>
        <source>&lt;p&gt;Version %1 is now available, &lt;a href=&quot;%2&quot;&gt;visit website&lt;/a&gt;.&lt;/p&gt;</source>
        <translation type="finished">&lt;p&gt;Dostępna jest wersja %1, &lt;a href=&quot;%2&quot;&gt;odwiedź stronę internetową&lt;/a&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="458"/>
        <source>Program can not be started</source>
        <translation type="finished">Nie można uruchomić programu</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="458"/>
        <source>The executable&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;could not be successfully started, although it does exist. Please check if you have sufficient permissions to run this program.</source>
        <translation type="finished">Plik wykonawczy&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;nie został poprawnie uruchomiony, mimo, że istnieje. Proszę sprawdzić czy dane konto posiada odpowiednie uprawnienia do uruchomienia wskazanej aplikacji.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="477"/>
        <source>Synergy client not found</source>
        <translation type="finished">Klient Synergy nie został odnaleziony</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="478"/>
        <source>The executable for the synergy client does not exist.</source>
        <translation type="finished">Plik wykonywalny klienta synergy nie istnieje</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="485"/>
        <source>Hostname is empty</source>
        <translation type="finished">Pole &quot;Nazwa hosta&quot; jest puste</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="486"/>
        <source>Please fill in a hostname for the synergy client to connect to.</source>
        <translation type="finished">Wypełnij nazwę hosta do której ma się podłączyć klient synergy.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="511"/>
        <source>Cannot write configuration file</source>
        <translation type="finished">Nie można zapisać pliku konfiguracyjnego</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="511"/>
        <source>The temporary configuration file required to start synergy can not be written.</source>
        <translation type="finished">Nie można zapisać tymczasowego pliku konfiguracyjnego wymaganego do uruchomienia synergy.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="524"/>
        <source>Configuration filename invalid</source>
        <translation type="finished">Niewłaściwa nazwa pliku konfiguracyjnego</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="525"/>
        <source>You have not filled in a valid configuration file for the synergy server. Do you want to browse for the configuration file now?</source>
        <translation type="finished">Nie podałeś poprawnego pliku konfiguracji potrzebnego do uruchomienia serwera synergy. Czy chcesz wskazać ten plik teraz?</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="552"/>
        <source>Synergy server not found</source>
        <translation type="finished">Nie znaleziono serwera Synergy</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="553"/>
        <source>The executable for the synergy server does not exist.</source>
        <translation type="finished">Plik wykonywalny serwera synergy nie istnieje</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="617"/>
        <source>Synergy terminated with an error</source>
        <translation type="finished">Synergy zostało zatrzymane z błędem</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="617"/>
        <source>Synergy terminated unexpectedly with an exit code of %1.&lt;br&gt;&lt;br&gt;Please see the log output for details.</source>
        <translation type="finished">Synergy zakończył działanie w sposób nieoczekiwany, kod wyjścia %1 (exit code). &lt;br&gt;&lt;br&gt;Więcej szczegółów w pliku logów wyjściowych.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="636"/>
        <source>&amp;Stop</source>
        <translation type="finished">Stop</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="659"/>
        <source>service mode</source>
        <translation type="finished">tryb serwisowy</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="659"/>
        <source>desktop mode</source>
        <translation type="finished">tryb aplikacji</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="660"/>
        <source>Synergy is running (%1).</source>
        <translation type="finished">Synergy jest uruchomione (%1)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="821"/>
        <source>Elevate Synergy</source>
        <translation type="finished">Zwiększ uprawnienia Synergy</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="822"/>
        <source>Are you sure you want to elevate Synergy?

This allows Synergy to interact with elevated processes and the UAC dialog, but can cause problems with non-elevated processes. Elevate Synergy only if you really need to.</source>
        <translation type="finished">Czy jesteś pewien, żeby podnieść uprawnienia Synergy?
Pozwoli to Synergy współpracować z innymi aplikacjami o podniesionych uprawnieniach oraz systemem UAC, ale może stwarzać problemy z aplikacjami bez podniesionych uprawnień. Podnoś uprawnienia tylko w sytuacji, gdy naprawdę tego potrzebujesz.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="664"/>
        <source>Synergy is starting.</source>
        <translation type="finished">Synergy jest uruchamiane.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="667"/>
        <source>Synergy is not running.</source>
        <translation type="finished">Synergy nie uruchomione.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="724"/>
        <source>Unknown</source>
        <translation type="finished">Nieznane</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="762"/>
        <source>Browse for a synergys config file</source>
        <translation type="finished">Wskaż plik konfiguracyjny synergy</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="775"/>
        <source>Save configuration as...</source>
        <translation type="finished">Zachowaj konfigurację jako…</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="779"/>
        <source>Save failed</source>
        <translation type="finished">Błąd zapisu</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="779"/>
        <source>Could not save configuration to file.</source>
        <translation type="finished">Nie można zapisać konfiguracji do pliku.</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="res/MainWindowBase.ui" line="26"/>
        <source>Synergy</source>
        <translation type="finished">Synergy</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="54"/>
        <source>Screen name:</source>
        <translation type="finished">Nazwa ekranu:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="61"/>
        <source>&amp;Server IP:</source>
        <translation type="finished">IP &amp;serwera</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="160"/>
        <location filename="res/MainWindowBase.ui" line="315"/>
        <source>&amp;Start</source>
        <translation type="finished">Start</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="187"/>
        <source>&amp;Server (share this computer's mouse and keyboard):</source>
        <translation type="finished">&amp;Serwer (udostępnij mysz i klawiaturę tego komputera)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="254"/>
        <source>Use existing configuration:</source>
        <translation type="finished">Użyj istniejącej konfiguracji:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="263"/>
        <source>&amp;Configuration file:</source>
        <translation type="finished">&amp;Plik konfiguracyjny:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="283"/>
        <source>&amp;Browse...</source>
        <translation type="finished">Wyszukaj...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="220"/>
        <source>Configure interactively:</source>
        <translation type="finished">Konfiguruj interaktywnie:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="232"/>
        <source>&amp;Configure Server...</source>
        <translation type="finished">Konfiguruj Serwer...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="39"/>
        <source>&amp;Client (use another computer's keyboard and mouse):</source>
        <translation type="finished">&amp;Klient (używaj klawiatury i myszy innego komputera)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="84"/>
        <source>Ready</source>
        <translation type="finished">Gotowe</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="91"/>
        <source>Log</source>
        <translation type="finished">Log</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="167"/>
        <source>&amp;Apply</source>
        <translation type="finished">&amp;Zastosuj</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="174"/>
        <source>&amp;Elevate</source>
        <translation type="finished">Zwiększ uprawnienia Synergy</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="204"/>
        <source>IP addresses:</source>
        <translation type="finished">Adresy IP:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="296"/>
        <source>&amp;About Synergy...</source>
        <translation type="finished">O Synergy...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="304"/>
        <source>&amp;Quit</source>
        <translation type="finished">Zakończ</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="307"/>
        <source>Quit</source>
        <translation type="finished">Zakończ</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="318"/>
        <source>Run</source>
        <translation type="finished">Uruchom</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="329"/>
        <source>S&amp;top</source>
        <translation type="finished">Zatrzymaj</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="332"/>
        <source>Stop</source>
        <translation type="finished">Zatrzymaj</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="340"/>
        <source>S&amp;how Status</source>
        <translation type="finished">Pokaż status</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="348"/>
        <source>&amp;Hide</source>
        <translation type="finished">&amp;Ukryj</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="351"/>
        <source>Hide</source>
        <translation type="finished">Ukryj</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="359"/>
        <source>&amp;Show</source>
        <translation type="finished">&amp;Pokaż</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="362"/>
        <source>Show</source>
        <translation type="finished">Pokaż</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="370"/>
        <source>Save configuration &amp;as...</source>
        <translation type="finished">Zapisz konfigurację jako...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="373"/>
        <source>Save the interactively generated server configuration to a file.</source>
        <translation type="finished">Zapisz interaktywnie wygenerowaną konfigurację serwera do pliku.</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="381"/>
        <source>Settings</source>
        <translation type="finished">Ustawienia</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="384"/>
        <source>Edit settings</source>
        <translation type="finished">Edytuj ustawienia</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="392"/>
        <source>Run Wizard</source>
        <translation type="finished">Uruchom Kreatora</translation>
    </message>
</context>
<context>
    <name>NewScreenWidget</name>
    <message>
        <location filename="src/NewScreenWidget.cpp" line="32"/>
        <source>Unnamed</source>
        <translation type="finished">Nienazwany</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="src/MainWindow.cpp" line="45"/>
        <source>Synergy Configurations (*.sgc);;All files (*.*)</source>
        <translation type="finished">Konfiguracje Synergy (*.sgc);;Wszystkie pliki (*.*)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="48"/>
        <source>Synergy Configurations (*.conf);;All files (*.*)</source>
        <translation type="finished">Konfiguracje Synergy (*.conf);;Wszystkie pliki (*.*)</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="90"/>
        <source>System tray is unavailable, quitting.</source>
        <translation type="finished">Tacka systemowa niedostępna, zamykanie…</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialog</name>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="65"/>
        <source>Screen name is empty</source>
        <translation type="finished">Nazwa ekranu jest pusta</translation>
    </message>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="65"/>
        <source>The name for a screen can not be empty. Please fill in a name or cancel the dialog.</source>
        <translation type="finished">Nazwa ekranu nie może być pusta. Wprowadź nazwę lub anuluj to okno dialogowe.</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialogBase</name>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="14"/>
        <source>Screen Settings</source>
        <translation type="finished">Ustawienia ekranu</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="22"/>
        <source>Screen &amp;name:</source>
        <translation type="finished">Nazwa ekranu:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="42"/>
        <source>A&amp;liases</source>
        <translation type="finished">Aliasy</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="57"/>
        <source>&amp;Add</source>
        <translation type="finished">Dodaj</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="74"/>
        <source>&amp;Remove</source>
        <translation type="finished">Usuń</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="97"/>
        <source>&amp;Modifier keys</source>
        <translation type="finished">Klawisze &amp;modyfikujące</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="106"/>
        <source>&amp;Shift:</source>
        <translation type="finished">Shift</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="117"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="164"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="211"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="258"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="305"/>
        <source>Shift</source>
        <translation type="finished">Shift</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="122"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="169"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="216"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="263"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="310"/>
        <source>Ctrl</source>
        <translation type="finished">Ctrl</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="127"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="174"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="221"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="268"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="315"/>
        <source>Alt</source>
        <translation type="finished">Alt</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="132"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="179"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="226"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="273"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="320"/>
        <source>Meta</source>
        <translation type="finished">Meta</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="137"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="184"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="231"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="278"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="325"/>
        <source>Super</source>
        <translation type="finished">Super</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="142"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="189"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="236"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="283"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="330"/>
        <source>None</source>
        <translation type="finished">Żaden</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="150"/>
        <source>&amp;Ctrl:</source>
        <translation type="finished">&amp;Ctrl:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="197"/>
        <source>Al&amp;t:</source>
        <translation type="finished">Al&amp;t:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="244"/>
        <source>M&amp;eta:</source>
        <translation type="finished">M&amp;eta:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="291"/>
        <source>S&amp;uper:</source>
        <translation type="finished">S&amp;uper:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="358"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">Narożniki nieczynne</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="367"/>
        <source>Top-left</source>
        <translation type="finished">Lewy-górny</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="374"/>
        <source>Top-right</source>
        <translation type="finished">Prawy-górny</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="381"/>
        <source>Bottom-left</source>
        <translation type="finished">Lewy-dół</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="388"/>
        <source>Bottom-right</source>
        <translation type="finished">Prawy-dół</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="397"/>
        <source>Corner Si&amp;ze:</source>
        <translation type="finished">Wielkość narożników:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="428"/>
        <source>&amp;Fixes</source>
        <translation type="finished">Poprawki</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="437"/>
        <source>Fix CAPS LOCK key</source>
        <translation type="finished">Wyłącz przycisk CAPS LOCK</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="444"/>
        <source>Fix NUM LOCK key</source>
        <translation type="finished">Wyłącz przycisk NUM LOCK</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="451"/>
        <source>Fix SCROLL LOCK key</source>
        <translation type="finished">Napraw przycisk SCROLL LOCK</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="458"/>
        <source>Fix XTest for Xinerama</source>
        <translation type="finished">Napraw XTest w Xinerama</translation>
    </message>
</context>
<context>
    <name>ScreenSetupModel</name>
    <message>
        <location filename="src/ScreenSetupModel.cpp" line="51"/>
        <source>&lt;center&gt;Screen: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;Double click to edit settings&lt;br&gt;Drag screen to the trashcan to remove it</source>
        <translation type="finished">&lt;center&gt;Ekran: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;Kliknij dwukrotnie, aby edytować ustawienia&lt;br&gt;Przeciągnij ekran do kosza, aby go usunąć</translation>
    </message>
</context>
<context>
    <name>ServerConfigDialogBase</name>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="13"/>
        <source>Server Configuration</source>
        <translation type="finished">Konfiguracja serwera</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="23"/>
        <source>Screens and links</source>
        <translation type="finished">Ekrany i połączenia</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="34"/>
        <source>Drag a screen from the grid to the trashcan to remove it.</source>
        <translation type="finished">Przeciągnij ekran z siatki do kosza, aby go usunąć.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="59"/>
        <source>Configure the layout of your synergy server configuration.</source>
        <translation type="finished">Konfiguracja układu serwera synergy.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="72"/>
        <source>Drag this button to the grid to add a new screen.</source>
        <translation type="finished">Żeby dodać nowy ekran, przesuń ten przycisk na siatkę.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="127"/>
        <source>Drag new screens to the grid or move existing ones around.
Drag a screen to the trashcan to delete it.
Double click on a screen to edit its settings.</source>
        <translation type="finished">Przeciągnij nowe ekrany na siatkę lub przenoś istniejące.
Przeciągnij ekran do kosza, aby go usunąć.
Kliknij dwukrotnie w ekran, aby edytować jego ustawienia.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="156"/>
        <source>Hotkeys</source>
        <translation type="finished">Skróty klawiszowe</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="162"/>
        <source>&amp;Hotkeys</source>
        <translation type="finished">Skróty klawiszowe</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="174"/>
        <source>&amp;New</source>
        <translation type="finished">&amp;Nowy</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="184"/>
        <source>&amp;Edit</source>
        <translation type="finished">Edytuj</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="194"/>
        <source>&amp;Remove</source>
        <translation type="finished">Usuń</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="217"/>
        <source>A&amp;ctions</source>
        <translation type="finished">Czynności</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="229"/>
        <source>Ne&amp;w</source>
        <translation type="finished">No&amp;wy</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="239"/>
        <source>E&amp;dit</source>
        <translation type="finished">E&amp;dytuj</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="249"/>
        <source>Re&amp;move</source>
        <translation type="finished">U&amp;suń</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="273"/>
        <source>Advanced server settings</source>
        <translation type="finished">Zaawansowane ustawienia serwera</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="279"/>
        <source>&amp;Switch</source>
        <translation type="finished">Przełącz</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="290"/>
        <source>Switch &amp;after waiting</source>
        <translation type="finished">Przełącz po odczekaniu</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="329"/>
        <location filename="res/ServerConfigDialogBase.ui" line="382"/>
        <location filename="res/ServerConfigDialogBase.ui" line="457"/>
        <source>ms</source>
        <translation type="finished">ms</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="343"/>
        <source>Switch on double &amp;tap within</source>
        <translation type="finished">Przełącz po podwójnym stuknięciu w</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="407"/>
        <source>&amp;Options</source>
        <translation type="finished">&amp;Opcje</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="418"/>
        <source>&amp;Check clients every</source>
        <translation type="finished">Sprawdź klientów co każde</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="469"/>
        <source>Use &amp;relative mouse moves</source>
        <translation type="finished">Użyj względnych ruchów myszki</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="479"/>
        <source>S&amp;ynchronize screen savers</source>
        <translation type="finished">S&amp;ynchronizuj wygaszacze ekranu</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="489"/>
        <source>Don't take &amp;foreground window on Windows servers</source>
        <translation type="finished">Nie zmieniaj statusu okna na &amp;wierzch w systemie Windows.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="512"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">Narożniki nieczynne</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="521"/>
        <source>To&amp;p-left</source>
        <translation type="finished">Górny-lewy</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="528"/>
        <source>Top-rig&amp;ht</source>
        <translation type="finished">Górny-prawy</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="535"/>
        <source>&amp;Bottom-left</source>
        <translation type="finished">Dolny-lewy</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="542"/>
        <source>Bottom-ri&amp;ght</source>
        <translation type="finished">Dolny-prawy</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="564"/>
        <source>Cor&amp;ner Size:</source>
        <translation type="finished">Wielkość narożnika:</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="src/SettingsDialog.cpp" line="62"/>
        <source>Encryption password must not be empty.</source>
        <translation type="finished">Hasło szyfrowania nie może być puste.</translation>
    </message>
    <message>
        <location filename="src/SettingsDialog.cpp" line="121"/>
        <source>Save log file to...</source>
        <translation type="finished">Zapisz logi do...</translation>
    </message>
</context>
<context>
    <name>SettingsDialogBase</name>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="14"/>
        <source>Settings</source>
        <translation type="finished">Ustawienia</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="165"/>
        <source>&amp;Advanced</source>
        <translation type="finished">Zaawansowane</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="177"/>
        <source>Sc&amp;reen name:</source>
        <translation type="finished">Nazwa ekranu:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="194"/>
        <source>P&amp;ort:</source>
        <translation type="finished">Port:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="223"/>
        <source>&amp;Interface:</source>
        <translation type="finished">Interfejs:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="26"/>
        <source>&amp;Start Synergy after logging in</source>
        <translation type="finished">Po zalogowaniu uruchom Synergy</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="33"/>
        <source>&amp;Automatically start server/client</source>
        <translation type="finished">Automatycznie uruchom serwer/klienta</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="40"/>
        <source>&amp;Hide when server/client starts</source>
        <translation type="finished">Ukryj gdy serwer/klient startuje</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="273"/>
        <source>Logging</source>
        <translation type="finished">Logowanie</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="240"/>
        <source>&amp;Process mode:</source>
        <translation type="finished">Uruchom jako:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="251"/>
        <source>Service</source>
        <translation type="finished">Usługa</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="256"/>
        <source>Desktop (legacy)</source>
        <translation type="finished">Puplit (dziedziczony)</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="291"/>
        <source>&amp;Logging level:</source>
        <translation type="finished">Poziom logowania:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="340"/>
        <source>Log to file:</source>
        <translation type="finished">Zapisuj logi do pliku:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="357"/>
        <source>Browse...</source>
        <translation type="finished">Przeglądaj...</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="302"/>
        <source>Error</source>
        <translation type="finished">Błąd</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="20"/>
        <source>&amp;Graphical interface</source>
        <translation type="finished">Interfejs graficzny</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="55"/>
        <source>&amp;Language:</source>
        <translation type="finished">Język</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="82"/>
        <source>&amp;Encryption</source>
        <translation type="finished">Szyfrowanie</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="97"/>
        <source>&amp;Mode:</source>
        <translation type="finished">Tryb:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="142"/>
        <source>Pass&amp;word:</source>
        <translation type="finished">Hasło:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="307"/>
        <source>Warning</source>
        <translation type="finished">Ostrzeżenie</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="312"/>
        <source>Note</source>
        <translation type="finished">Uwaga</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="317"/>
        <source>Info</source>
        <translation type="finished">Info</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="322"/>
        <source>Debug</source>
        <translation type="finished">Debug</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="327"/>
        <source>Debug1</source>
        <translation type="finished">Debug1</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="332"/>
        <source>Debug2</source>
        <translation type="finished">Debug2</translation>
    </message>
</context>
<context>
    <name>SetupWizard</name>
    <message>
        <location filename="src/SetupWizard.cpp" line="64"/>
        <source>Setup Synergy</source>
        <translation type="finished">Konfiguracja Synergy</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="74"/>
        <source>Please select an option.</source>
        <translation type="finished">Proszę wybrać opcję,</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="84"/>
        <source>Encryption mode required.</source>
        <translation type="finished">Tryb szyfrowania wymagany.</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="93"/>
        <source>Encryption password required.</source>
        <translation type="finished">Hasło szyfrowania wymagane.</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="100"/>
        <source>Encryption password and confirmation do not match.</source>
        <translation type="finished">Hasło szyfrowania i jego potwierdzenie różnią się.</translation>
    </message>
</context>
<context>
    <name>SetupWizardBase</name>
    <message>
        <location filename="res/SetupWizardBase.ui" line="20"/>
        <source>Setup Synergy</source>
        <translation type="finished">Konfiguracja Synergy</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="24"/>
        <source>Welcome</source>
        <translation type="finished">Witaj!</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="33"/>
        <source>Thanks for installing Synergy!</source>
        <translation type="finished">Dziękujemy za zainstalowanie Synergy!</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="108"/>
        <source>Synergy lets you easily share your mouse and keyboard between multiple computers on your desk, and it's Free and Open Source. Just move your mouse off the edge of one computer's screen on to another. You can even share all of your clipboards. All you need is a network connection. Synergy is cross-platform (works on Windows, Mac OS X and Linux).</source>
        <translation type="finished">Synergy pozwala w łatwy sposób dzielić się myszką i klawiaturą pomiędzy wieloma komputerami na Twoim biurku, jest darmowe i Open Source. Wystarczy przesunąć kursor myszy poza krawędź jednego monitora aby przejść na monitor innego komputera.  Możesz nawet dzielić wszystkie swoje schowki. Potrzebujesz do tego tylko połączenia z siecią. Synergy jest wieloplatformowe (działa na Windows, Mac OS X i Linux).</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="125"/>
        <source>Server or Client?</source>
        <translation type="finished">Klient czy Serwer?</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="140"/>
        <source>&amp;Server (new setup)</source>
        <translation type="finished">&amp;Serwer (nowa konfiguracja)</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="153"/>
        <source>This is the first computer you are configuring. Your keyboard and mouse are connected to this computer. This will allow you to move your mouse over to another computer's screen. There can only be one server in your setup.</source>
        <translation type="finished">To pierwszy komputer, który konfigurujesz. Do tego komputera podłączona jest klawiatura i mysz. Pozwoli to na przesuwanie wskaźnika myszy na ekran innego komputera. W pojedynczej konfiguracji może być tylko jeden serwer.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="185"/>
        <source>&amp;Client (add to setup)</source>
        <translation type="finished">&amp;Klient (dodaj do konfiguracji)</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="198"/>
        <source>You have already set up a server. This is a computer you wish to control using the server's keyboard and mouse. There can be many clients in your setup.</source>
        <oldsource>You have already set up a server. This a computer you wish to control using the server's keyboard and mouse. There can be many clients in your setup.</oldsource>
        <translation type="finished">Serwer został już wcześniej skonfigurowany. To jest komputer, którym chcesz sterować przy użyciu klawiatury i myszy serwera. W pojedynczej konfiguracji może być wiele klientów.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="231"/>
        <source>Encryption</source>
        <translation type="finished">Szyfrowanie</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="237"/>
        <source>Network traffic can be easily monitored. Using encryption can reduce the risk that sensitive information will be revealed to others (for example, passwords).</source>
        <translation type="finished">Ruch w sieci może być łatwo monitorowany. Szyfrowanie obniża ryzyko odczytania przez osoby postronne poufnych danych (np. haseł) .</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="263"/>
        <source>Choose a random encryption mode. The mode must be the same on both the client and server.</source>
        <translation type="finished">Wybierz losowy tryb szyfrowania. Tryb ten musi być identyczny  na obu komputerach - na kliencie i serwerze.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="308"/>
        <source>&amp;Mode:</source>
        <translation type="finished">Tryb:</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="391"/>
        <source>A longer password will provide stronger encryption. It is a good idea to use 20 characters or more.</source>
        <translation type="finished">Im dłuższe hasło tym lepsze szyfrowanie. Warto użyć co najmniej 20 znaków.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="415"/>
        <source>&amp;Password:</source>
        <translation type="finished">Hasło:</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="474"/>
        <source>&amp;Confirm:</source>
        <translation type="finished">Potwierdź:</translation>
    </message>
</context>
<context>
    <name>VersionChecker</name>
    <message>
        <location filename="src/VersionChecker.cpp" line="102"/>
        <source>Unknown</source>
        <translation type="finished">Nieznane</translation>
    </message>
</context>
</TS>