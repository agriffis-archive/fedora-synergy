<?xml version="1.0" encoding="utf-8"?><!DOCTYPE TS><TS language="ro" sourcelanguage="en" version="2.0">
<context>
    <name>AboutDialogBase</name>
    <message>
        <location filename="res/AboutDialogBase.ui" line="38"/>
        <source>About Synergy</source>
        <translation type="finished">Sobre o Synergy</translation>
    </message>
    <message utf8="true">
        <location filename="res/AboutDialogBase.ui" line="53"/>
        <source>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Synergy GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (synergy-foss.org).
&lt;/p&gt;</source>
        <oldsource>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Synergy GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (synergy-foss.org).
&lt;/p&gt;</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="140"/>
        <source>Unknown</source>
        <translation type="finished">Necunoscut</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="124"/>
        <source>Version:</source>
        <translation type="finished">Versiune:</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="163"/>
        <source>&amp;Ok</source>
        <translation type="finished">Ok</translation>
    </message>
</context>
<context>
    <name>ActionDialogBase</name>
    <message>
        <location filename="res/ActionDialogBase.ui" line="14"/>
        <source>Configure Action</source>
        <translation type="finished">Confirmă Acțiunea</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="20"/>
        <source>Choose the action to perform</source>
        <translation type="finished">Alege acțiunea pentru a o efectua</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="26"/>
        <source>Press a hotkey</source>
        <translation type="finished">Apasă o tastă rapidă</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="36"/>
        <source>Release a hotkey</source>
        <translation type="finished">Eliberează o tastă rapidă</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="43"/>
        <source>Press and release a hotkey</source>
        <translation type="finished">Apăsaţi şi eliberaţi o tastă rapidă</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="69"/>
        <source>only on these screens</source>
        <translation type="finished">doar pe aceste ecrane</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="119"/>
        <source>Switch to screen</source>
        <translation type="finished">Comută la ecran</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="150"/>
        <source>Switch in direction</source>
        <translation type="finished">Comută în direcția</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="174"/>
        <source>left</source>
        <translation type="finished">stânga</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="179"/>
        <source>right</source>
        <translation type="finished">dreapta</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="184"/>
        <source>up</source>
        <translation type="finished">sus</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="189"/>
        <source>down</source>
        <translation type="finished">jos</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="201"/>
        <source>Lock cursor to screen</source>
        <translation type="finished">Blochează cursorul la ecran</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="225"/>
        <source>toggle</source>
        <translation type="finished">comută</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="230"/>
        <source>on</source>
        <translation type="finished">Ligado</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="235"/>
        <source>off</source>
        <translation type="finished">Desligado</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="248"/>
        <source>This action is performed when</source>
        <translation type="finished">Această acțiune este executată când</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="254"/>
        <source>the hotkey is pressed</source>
        <translation type="finished">o tastă rapidă este apăsată</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="264"/>
        <source>the hotkey is released</source>
        <translation type="finished">o tastă rapidă este eliberată</translation>
    </message>
</context>
<context>
    <name>HotkeyDialogBase</name>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="14"/>
        <source>Hotkey</source>
        <translation type="finished"> Tastă rapidă</translation>
    </message>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="20"/>
        <source>Enter the specification for the hotkey:</source>
        <translation type="finished">Introdu specificație pentru tasta rapidă:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="src/MainWindow.cpp" line="642"/>
        <source>&amp;Start</source>
        <translation type="finished">&amp;Start</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="196"/>
        <source>&amp;File</source>
        <translation type="finished">&amp;Fișier</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="197"/>
        <source>&amp;Edit</source>
        <translation type="finished">&amp;Editează</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="198"/>
        <source>&amp;Window</source>
        <translation type="finished">&amp;Fereastră</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="199"/>
        <source>&amp;Help</source>
        <translation type="finished">&amp;Ajutor</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="326"/>
        <source>&lt;p&gt;Version %1 is now available, &lt;a href=&quot;%2&quot;&gt;visit website&lt;/a&gt;.&lt;/p&gt;</source>
        <translation type="finished">&lt;p&gt;Versionea %1 este disponibilă acuma, &lt;a href=&quot;%2&quot;&gt;vizitează website&lt;/a&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="458"/>
        <source>Program can not be started</source>
        <translation type="finished">Programul nu poate fi pornit</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="458"/>
        <source>The executable&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;could not be successfully started, although it does exist. Please check if you have sufficient permissions to run this program.</source>
        <translation type="finished">Executabilul&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;nu a putut fi pornit cu succes, deși există. Te rog verifică dacă ai suficiente permisiuni pentru a rula acest program.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="477"/>
        <source>Synergy client not found</source>
        <translation type="finished">Clientul Synergy nu poate fi găsit</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="478"/>
        <source>The executable for the synergy client does not exist.</source>
        <translation type="finished">Executabilul pentru clientul synergy nu există.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="485"/>
        <source>Hostname is empty</source>
        <translation type="finished">Numele gazdă este gol</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="486"/>
        <source>Please fill in a hostname for the synergy client to connect to.</source>
        <translation type="finished">Te rog să complectezi numele de gazda pentru clientul synergy la care să te conectezi.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="511"/>
        <source>Cannot write configuration file</source>
        <translation type="finished">Fișierul de configurare nu poate fi scris</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="511"/>
        <source>The temporary configuration file required to start synergy can not be written.</source>
        <translation type="finished">Fișierul de configurare temporar necesar pentru a porni Synergy nu poate fi scris</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="524"/>
        <source>Configuration filename invalid</source>
        <translation type="finished">Arquivo de configuração inválido.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="525"/>
        <source>You have not filled in a valid configuration file for the synergy server. Do you want to browse for the configuration file now?</source>
        <translation type="finished">Nu ati completat un fişier de configurare valabil pentru serverul synergy. Doriţi să răsfoiţi pentru un fişierul de configurare acum?</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="552"/>
        <source>Synergy server not found</source>
        <translation type="finished">Clientul Synergy nu poate fi găsit</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="553"/>
        <source>The executable for the synergy server does not exist.</source>
        <translation type="finished">Executabilul pentru clientul synergy nu există.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="617"/>
        <source>Synergy terminated with an error</source>
        <translation type="finished">Synergy terminou com um erro</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="617"/>
        <source>Synergy terminated unexpectedly with an exit code of %1.&lt;br&gt;&lt;br&gt;Please see the log output for details.</source>
        <translation type="finished">Synergy a terminat în mod neaşteptat cu un cod  %1.&lt;br&gt;&lt;br&gt;Vă rugăm să consultaţi jurnalul pentru detalii.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="636"/>
        <source>&amp;Stop</source>
        <translation type="finished">&amp;Stop</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="659"/>
        <source>service mode</source>
        <translation type="finished">Modul serviciului.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="659"/>
        <source>desktop mode</source>
        <translation type="finished">Mod de desktop.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="660"/>
        <source>Synergy is running (%1).</source>
        <translation type="finished">Synergy ruleaza (%1).</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="821"/>
        <source>Elevate Synergy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="822"/>
        <source>Are you sure you want to elevate Synergy?

This allows Synergy to interact with elevated processes and the UAC dialog, but can cause problems with non-elevated processes. Elevate Synergy only if you really need to.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="664"/>
        <source>Synergy is starting.</source>
        <translation type="finished">Synergy pornește.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="667"/>
        <source>Synergy is not running.</source>
        <translation type="finished">Synergy nu rulează.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="724"/>
        <source>Unknown</source>
        <translation type="finished">Necunoscut</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="762"/>
        <source>Browse for a synergys config file</source>
        <translation type="finished">Răsfoiţi pentru un fişierul de configurare synergy</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="775"/>
        <source>Save configuration as...</source>
        <translation type="finished">Salvează configurația ca...</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="779"/>
        <source>Save failed</source>
        <translation type="finished">Salvare eșuată</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="779"/>
        <source>Could not save configuration to file.</source>
        <translation type="finished">Nu sa putut salva configurația în fișier.</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="res/MainWindowBase.ui" line="26"/>
        <source>Synergy</source>
        <translation type="finished">Synergy</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="54"/>
        <source>Screen name:</source>
        <translation type="finished">Nume de utilizator:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="61"/>
        <source>&amp;Server IP:</source>
        <translation type="finished">IP-ul Server-ului:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="160"/>
        <location filename="res/MainWindowBase.ui" line="315"/>
        <source>&amp;Start</source>
        <translation type="finished">&amp;Start</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="187"/>
        <source>&amp;Server (share this computer's mouse and keyboard):</source>
        <translation type="finished">Server (partajează mouse-ul și tastatura acestui calculator):</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="254"/>
        <source>Use existing configuration:</source>
        <translation type="finished">Folosește configurație existentă:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="263"/>
        <source>&amp;Configuration file:</source>
        <translation type="finished">Fișier de configurare:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="283"/>
        <source>&amp;Browse...</source>
        <translation type="finished">Răsfoiește...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="220"/>
        <source>Configure interactively:</source>
        <translation type="finished">Configurare interactivă:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="232"/>
        <source>&amp;Configure Server...</source>
        <translation type="finished">Configurează Server...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="39"/>
        <source>&amp;Client (use another computer's keyboard and mouse):</source>
        <translation type="finished">Client (folosește mouse-ul și tastatura a altui calculator):</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="84"/>
        <source>Ready</source>
        <translation type="finished">Gata</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="91"/>
        <source>Log</source>
        <translation type="finished">Log</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="167"/>
        <source>&amp;Apply</source>
        <translation type="finished">Aplică</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="174"/>
        <source>&amp;Elevate</source>
        <translation type="finished">Ridica</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="204"/>
        <source>IP addresses:</source>
        <translation type="finished">Adrese IP:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="296"/>
        <source>&amp;About Synergy...</source>
        <translation type="finished">Despre Synergy...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="304"/>
        <source>&amp;Quit</source>
        <translation type="finished">&amp;Ieșire</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="307"/>
        <source>Quit</source>
        <translation type="finished">Ieșire</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="318"/>
        <source>Run</source>
        <translation type="finished">Pornește</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="329"/>
        <source>S&amp;top</source>
        <translation type="finished">Stop</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="332"/>
        <source>Stop</source>
        <translation type="finished">Stop</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="340"/>
        <source>S&amp;how Status</source>
        <translation type="finished">Arată Statutul</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="348"/>
        <source>&amp;Hide</source>
        <translation type="finished">Ascunde </translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="351"/>
        <source>Hide</source>
        <translation type="finished">Ascunde </translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="359"/>
        <source>&amp;Show</source>
        <translation type="finished">Afişează</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="362"/>
        <source>Show</source>
        <translation type="finished">Afişează </translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="370"/>
        <source>Save configuration &amp;as...</source>
        <translation type="finished">Salvează configurația ca...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="373"/>
        <source>Save the interactively generated server configuration to a file.</source>
        <translation type="finished">Salvaţi configuraţia generată interactiv a serverului într-un fişier.</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="381"/>
        <source>Settings</source>
        <translation type="finished">Setări</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="384"/>
        <source>Edit settings</source>
        <translation type="finished">Editează setările</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="392"/>
        <source>Run Wizard</source>
        <translation type="finished">Pornește Expertul</translation>
    </message>
</context>
<context>
    <name>NewScreenWidget</name>
    <message>
        <location filename="src/NewScreenWidget.cpp" line="32"/>
        <source>Unnamed</source>
        <translation type="finished">Anonim</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="src/MainWindow.cpp" line="45"/>
        <source>Synergy Configurations (*.sgc);;All files (*.*)</source>
        <translation type="finished">Configurații Synergy (*.sgc);;Toate Fișierele (*.*)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="48"/>
        <source>Synergy Configurations (*.conf);;All files (*.*)</source>
        <translation type="finished">Configurații Synergy (*.conf);;Toate Fișierele (*.*)</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="90"/>
        <source>System tray is unavailable, quitting.</source>
        <translation type="finished">Bara de sistem nu este disponibilă, renunțați.</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialog</name>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="65"/>
        <source>Screen name is empty</source>
        <translation type="finished">Numele de ecran este gol.</translation>
    </message>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="65"/>
        <source>The name for a screen can not be empty. Please fill in a name or cancel the dialog.</source>
        <translation type="finished">Numele pentru ecran nu poate fii gol. Vă rugăm introduceți un nume sau închideți fereastra.</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialogBase</name>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="14"/>
        <source>Screen Settings</source>
        <translation type="finished">Setări de ecran</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="22"/>
        <source>Screen &amp;name:</source>
        <translation type="finished">Nume de ecran.</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="42"/>
        <source>A&amp;liases</source>
        <translation type="finished">Aliasuri</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="57"/>
        <source>&amp;Add</source>
        <translation type="finished">&amp;Adaugă</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="74"/>
        <source>&amp;Remove</source>
        <translation type="finished">&amp;Elimină</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="97"/>
        <source>&amp;Modifier keys</source>
        <translation type="finished">Modificator de taste</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="106"/>
        <source>&amp;Shift:</source>
        <translation type="finished">Shift:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="117"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="164"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="211"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="258"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="305"/>
        <source>Shift</source>
        <translation type="finished">Shift</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="122"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="169"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="216"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="263"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="310"/>
        <source>Ctrl</source>
        <translation type="finished">Ctrl</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="127"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="174"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="221"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="268"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="315"/>
        <source>Alt</source>
        <translation type="finished">Alt</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="132"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="179"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="226"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="273"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="320"/>
        <source>Meta</source>
        <translation type="finished">Meta</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="137"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="184"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="231"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="278"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="325"/>
        <source>Super</source>
        <translation type="finished">Super</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="142"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="189"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="236"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="283"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="330"/>
        <source>None</source>
        <translation type="finished">Nici unul</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="150"/>
        <source>&amp;Ctrl:</source>
        <translation type="finished">&amp;Ctrl:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="197"/>
        <source>Al&amp;t:</source>
        <translation type="finished">&amp;Alt:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="244"/>
        <source>M&amp;eta:</source>
        <translation type="finished">Meta:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="291"/>
        <source>S&amp;uper:</source>
        <translation type="finished">Super:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="358"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">Colțuri moarte</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="367"/>
        <source>Top-left</source>
        <translation type="finished">Stânga-sus</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="374"/>
        <source>Top-right</source>
        <translation type="finished">Dreapta-sus</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="381"/>
        <source>Bottom-left</source>
        <translation type="finished">Stânga-jos</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="388"/>
        <source>Bottom-right</source>
        <translation type="finished">Dreapta-jos</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="397"/>
        <source>Corner Si&amp;ze:</source>
        <translation type="finished">Mărimea colțurilor:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="428"/>
        <source>&amp;Fixes</source>
        <translation type="finished">Corecții</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="437"/>
        <source>Fix CAPS LOCK key</source>
        <translation type="finished">Corectrează tasta CAPS LOCK</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="444"/>
        <source>Fix NUM LOCK key</source>
        <translation type="finished">Corectrează tasta NUM LOCK</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="451"/>
        <source>Fix SCROLL LOCK key</source>
        <translation type="finished">Corectrează tasta SCROLL LOCK</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="458"/>
        <source>Fix XTest for Xinerama</source>
        <translation type="finished">Corectează XTest pentru Xinerama</translation>
    </message>
</context>
<context>
    <name>ScreenSetupModel</name>
    <message>
        <location filename="src/ScreenSetupModel.cpp" line="51"/>
        <source>&lt;center&gt;Screen: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;Double click to edit settings&lt;br&gt;Drag screen to the trashcan to remove it</source>
        <translation type="finished">&lt;center&gt;Ecran: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;Dublu click pentru editare de setări&lt;br&gt;Glisați ecranul către coșul de gunoi pentru al elimina</translation>
    </message>
</context>
<context>
    <name>ServerConfigDialogBase</name>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="13"/>
        <source>Server Configuration</source>
        <translation type="finished">Configurările Serverului</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="23"/>
        <source>Screens and links</source>
        <translation type="finished">Ecrane și legături</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="34"/>
        <source>Drag a screen from the grid to the trashcan to remove it.</source>
        <translation type="finished">Glisați un ecran de pe grilă către coșul de gunoi pentru al elimina.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="59"/>
        <source>Configure the layout of your synergy server configuration.</source>
        <translation type="finished">Configurați aspectul serverului vostru synergy.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="72"/>
        <source>Drag this button to the grid to add a new screen.</source>
        <translation type="finished">Glisați acest buton pe grilă pentru a adăuga un nou ecran.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="127"/>
        <source>Drag new screens to the grid or move existing ones around.
Drag a screen to the trashcan to delete it.
Double click on a screen to edit its settings.</source>
        <translation type="finished">Glisați ecrane noi pe grilă sau mută cele existente.
Glisați un ecran către coșul de gunoi pentru al elimina.
Click dublu pe un ecran pentru ai edita setările.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="156"/>
        <source>Hotkeys</source>
        <translation type="finished">Taste rapide</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="162"/>
        <source>&amp;Hotkeys</source>
        <translation type="finished">&amp;Taste rapide</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="174"/>
        <source>&amp;New</source>
        <translation type="finished">Nou</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="184"/>
        <source>&amp;Edit</source>
        <translation type="finished">&amp;Editează</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="194"/>
        <source>&amp;Remove</source>
        <translation type="finished">&amp;Elimină</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="217"/>
        <source>A&amp;ctions</source>
        <translation type="finished">Acțiuni</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="229"/>
        <source>Ne&amp;w</source>
        <translation type="finished">Nou</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="239"/>
        <source>E&amp;dit</source>
        <translation type="finished">Editează</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="249"/>
        <source>Re&amp;move</source>
        <translation type="finished">Elimină</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="273"/>
        <source>Advanced server settings</source>
        <translation type="finished">Setari avansate server</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="279"/>
        <source>&amp;Switch</source>
        <translation type="finished">Comută</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="290"/>
        <source>Switch &amp;after waiting</source>
        <translation type="finished">Comută după o așteptare de</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="329"/>
        <location filename="res/ServerConfigDialogBase.ui" line="382"/>
        <location filename="res/ServerConfigDialogBase.ui" line="457"/>
        <source>ms</source>
        <translation type="finished">ms</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="343"/>
        <source>Switch on double &amp;tap within</source>
        <translation type="finished">Schimbă la atingere dubla în interiorul</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="407"/>
        <source>&amp;Options</source>
        <translation type="finished">Opțiuni</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="418"/>
        <source>&amp;Check clients every</source>
        <translation type="finished">Verifică clienți fiecare</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="469"/>
        <source>Use &amp;relative mouse moves</source>
        <translation type="finished">Folosește mișcări relative ale mouse-ului</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="479"/>
        <source>S&amp;ynchronize screen savers</source>
        <translation type="finished">Sincronizare protector de ecran</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="489"/>
        <source>Don't take &amp;foreground window on Windows servers</source>
        <translation type="finished">Nu luaţi fereastre de prim-plan pe servere Windows</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="512"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">Colțuri moarte</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="521"/>
        <source>To&amp;p-left</source>
        <translation type="finished">Stânga-sus</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="528"/>
        <source>Top-rig&amp;ht</source>
        <translation type="finished">Dreapta-sus</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="535"/>
        <source>&amp;Bottom-left</source>
        <translation type="finished">Stânga-jos</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="542"/>
        <source>Bottom-ri&amp;ght</source>
        <translation type="finished">Dreapta-jos</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="564"/>
        <source>Cor&amp;ner Size:</source>
        <translation type="finished">Mărime colțuri</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="src/SettingsDialog.cpp" line="62"/>
        <source>Encryption password must not be empty.</source>
        <translation type="finished">Parola encriptiei nu poate fi goala.</translation>
    </message>
    <message>
        <location filename="src/SettingsDialog.cpp" line="121"/>
        <source>Save log file to...</source>
        <translation type="finished">Salvează fișier jurnal pentru ...</translation>
    </message>
</context>
<context>
    <name>SettingsDialogBase</name>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="14"/>
        <source>Settings</source>
        <translation type="finished">Setări</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="165"/>
        <source>&amp;Advanced</source>
        <translation type="finished">Avansat</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="177"/>
        <source>Sc&amp;reen name:</source>
        <translation type="finished">Nume ecran:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="194"/>
        <source>P&amp;ort:</source>
        <translation type="finished">Port:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="223"/>
        <source>&amp;Interface:</source>
        <translation type="finished">Interfață:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="26"/>
        <source>&amp;Start Synergy after logging in</source>
        <translation type="finished">Pornește Synergy după logare</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="33"/>
        <source>&amp;Automatically start server/client</source>
        <translation type="finished">Pornește automat server/client</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="40"/>
        <source>&amp;Hide when server/client starts</source>
        <translation type="finished">Ascunde când server/client pornește</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="273"/>
        <source>Logging</source>
        <translation type="finished">Logging</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="240"/>
        <source>&amp;Process mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="251"/>
        <source>Service</source>
        <translation type="finished">Serviciu.</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="256"/>
        <source>Desktop (legacy)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="291"/>
        <source>&amp;Logging level:</source>
        <translation type="finished">Nivel logging</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="340"/>
        <source>Log to file:</source>
        <translation type="finished">Log în fișier</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="357"/>
        <source>Browse...</source>
        <translation type="finished">Răsfoiește:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="302"/>
        <source>Error</source>
        <translation type="finished">Eroare</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="20"/>
        <source>&amp;Graphical interface</source>
        <translation type="finished">Interfata Grafica</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="55"/>
        <source>&amp;Language:</source>
        <translation type="finished">Limba:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="82"/>
        <source>&amp;Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="97"/>
        <source>&amp;Mode:</source>
        <translation type="finished">Mod:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="142"/>
        <source>Pass&amp;word:</source>
        <translation type="finished">Pass&amp;word:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="307"/>
        <source>Warning</source>
        <translation type="finished">Avertisment</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="312"/>
        <source>Note</source>
        <translation type="finished">Notă</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="317"/>
        <source>Info</source>
        <translation type="finished">Informação</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="322"/>
        <source>Debug</source>
        <translation type="finished">Depanare</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="327"/>
        <source>Debug1</source>
        <translation type="finished">Depanare1</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="332"/>
        <source>Debug2</source>
        <translation type="finished">Depanare2</translation>
    </message>
</context>
<context>
    <name>SetupWizard</name>
    <message>
        <location filename="src/SetupWizard.cpp" line="64"/>
        <source>Setup Synergy</source>
        <translation type="finished">Configurare Synergy</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="74"/>
        <source>Please select an option.</source>
        <translation type="finished">Te rog selectează o opțiune.</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="84"/>
        <source>Encryption mode required.</source>
        <translation type="finished">Se cere modul pentru encriptie.</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="93"/>
        <source>Encryption password required.</source>
        <translation type="finished">Parola pentru encriptie este ceruta.</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="100"/>
        <source>Encryption password and confirmation do not match.</source>
        <translation type="finished">Parola encriptiei si confirmarea nu sunt la fel.</translation>
    </message>
</context>
<context>
    <name>SetupWizardBase</name>
    <message>
        <location filename="res/SetupWizardBase.ui" line="20"/>
        <source>Setup Synergy</source>
        <translation type="finished">Configurare Synergy</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="24"/>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="33"/>
        <source>Thanks for installing Synergy!</source>
        <translation type="finished">Va multumim ca a-ti instalat Synergy!</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="108"/>
        <source>Synergy lets you easily share your mouse and keyboard between multiple computers on your desk, and it's Free and Open Source. Just move your mouse off the edge of one computer's screen on to another. You can even share all of your clipboards. All you need is a network connection. Synergy is cross-platform (works on Windows, Mac OS X and Linux).</source>
        <translation type="finished">Synergy vă permite să partajaţi cu uşurinţă mouse-ul şi tastatura între mai multe computere de pe birou, si este gratuit şi open source. Doar mutaţi mouse-ul de pe marginea ecranului pe un calculator pe altul. Puteţi chiar partaja toate clipboarduri tale. Tot ce trebuie este o conexiune la reţea. Sinergia este cross-platform (funcţionează pe Windows, Mac OS X şi Linux).</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="125"/>
        <source>Server or Client?</source>
        <translation type="finished">Server sau Client?</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="140"/>
        <source>&amp;Server (new setup)</source>
        <translation type="finished">Server (configurare nouă)</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="153"/>
        <source>This is the first computer you are configuring. Your keyboard and mouse are connected to this computer. This will allow you to move your mouse over to another computer's screen. There can only be one server in your setup.</source>
        <translation type="finished">Acesta este primul computer pe care îl configurați. Tastatura şi mouse-ul sunt conectate la acest computer. Acest lucru va permite să vă mutaţi mouse-ul pe la un alt ecran a altui calculator. Nu poate fi decât un server în configuraţia dumneavoastră.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="185"/>
        <source>&amp;Client (add to setup)</source>
        <translation type="finished">Client (adaugă pentru a configura)</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="198"/>
        <source>You have already set up a server. This is a computer you wish to control using the server's keyboard and mouse. There can be many clients in your setup.</source>
        <oldsource>You have already set up a server. This a computer you wish to control using the server's keyboard and mouse. There can be many clients in your setup.</oldsource>
        <translation type="finished">Aţi stabilit deja un server. Acesta este un calculator pe care doriţi să controlaţi folosind tastatura şi mouse-ul serverului. Pot fii mai mulți clienti in configurarea dumneavoastră.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="231"/>
        <source>Encryption</source>
        <translation type="finished">Encriptie</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="237"/>
        <source>Network traffic can be easily monitored. Using encryption can reduce the risk that sensitive information will be revealed to others (for example, passwords).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="263"/>
        <source>Choose a random encryption mode. The mode must be the same on both the client and server.</source>
        <translation type="finished">Alegeti o metoda de encriptare la intamplare. Aceasta trebuie sa fie la fel cu cea de la server si cea de la client.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="308"/>
        <source>&amp;Mode:</source>
        <translation type="finished">Mod:</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="391"/>
        <source>A longer password will provide stronger encryption. It is a good idea to use 20 characters or more.</source>
        <translation type="finished">O parola mai complexa va furniza o encriptie mai puternica. Este o idee buna sa folositi 20 sau mai multe litere.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="415"/>
        <source>&amp;Password:</source>
        <translation type="finished">Parola:</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="474"/>
        <source>&amp;Confirm:</source>
        <translation type="finished">Confirma:</translation>
    </message>
</context>
<context>
    <name>VersionChecker</name>
    <message>
        <location filename="src/VersionChecker.cpp" line="102"/>
        <source>Unknown</source>
        <translation type="finished">Necunoscut</translation>
    </message>
</context>
</TS>