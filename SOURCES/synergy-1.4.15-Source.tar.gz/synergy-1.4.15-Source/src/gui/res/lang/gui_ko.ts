<?xml version="1.0" encoding="utf-8"?><!DOCTYPE TS><TS language="ko" sourcelanguage="en" version="2.0">
<context>
    <name>AboutDialogBase</name>
    <message>
        <location filename="res/AboutDialogBase.ui" line="38"/>
        <source>About Synergy</source>
        <translation type="finished">Synergy에 대하여</translation>
    </message>
    <message utf8="true">
        <location filename="res/AboutDialogBase.ui" line="53"/>
        <source>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Synergy GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (synergy-foss.org).
&lt;/p&gt;</source>
        <oldsource>&lt;p&gt;
Keyboard and mouse sharing application. Cross platform and open source.&lt;br /&gt;&lt;br /&gt;
Copyright © 2012 Bolton Software Ltd.&lt;br /&gt;
Copyright © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy is released under the GNU General Public License (GPLv2).&lt;br /&gt;&lt;br /&gt;
Synergy is based on CosmoSynergy by Richard Lee and Adam Feder.&lt;br /&gt;
The Synergy GUI is based on QSynergy by Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Visit our website for help and info (synergy-foss.org).
&lt;/p&gt;</oldsource>
        <translation type="finished">&lt;p&gt;
하나의 키보드와 마우스를 공유하여 여러 컴퓨터를 제어할 수 있는 응용 프로그램으로, 다양한 플랫폼을 지원하며 오픈 소스 입니다.&lt;br /&gt;&lt;br /&gt;
저작권 © 2012 볼튼 소프트웨어 (주) &lt;br /&gt;
저작권 © 2002-2012 Chris Schoeneman, Nick Bolton, Volker Lanz.&lt;br /&gt;&lt;br /&gt;
Synergy는 GNU 일반 공중 사용 허가서 (GPLv2) 아래에 배포하고 있습니다.&lt;br /&gt;&lt;br /&gt;
Synergy는 Richard Lee과 Adam Feder에 의해 개발된 CosmoSynergy에 기반을 두고 있습니다.&lt;br /&gt;
Synergy GUI는 Volker Lanz의 QSynergy에 기반을 두고 있습니다.&lt;br /&gt;&lt;br /&gt;
도움말 및 정보를 보시려면 저희 웹 사이트(synergy-foss.org)를 방문하세요.
&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="140"/>
        <source>Unknown</source>
        <translation type="finished">알수없음</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="124"/>
        <source>Version:</source>
        <translation type="finished">버전:</translation>
    </message>
    <message>
        <location filename="res/AboutDialogBase.ui" line="163"/>
        <source>&amp;Ok</source>
        <translation type="finished">확인(&amp;O)</translation>
    </message>
</context>
<context>
    <name>ActionDialogBase</name>
    <message>
        <location filename="res/ActionDialogBase.ui" line="14"/>
        <source>Configure Action</source>
        <translation type="finished">동작 설정</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="20"/>
        <source>Choose the action to perform</source>
        <translation type="finished">수행할 동작을 선택하세요</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="26"/>
        <source>Press a hotkey</source>
        <translation type="finished">단축키를 누르세요</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="36"/>
        <source>Release a hotkey</source>
        <translation type="finished">단축키를 놓으세요</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="43"/>
        <source>Press and release a hotkey</source>
        <translation type="finished">단축키를 눌렀다 놓으세요</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="69"/>
        <source>only on these screens</source>
        <translation type="finished">이 화면에서만</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="119"/>
        <source>Switch to screen</source>
        <translation type="finished">이 화면으로 전환</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="150"/>
        <source>Switch in direction</source>
        <translation type="finished">이 방향으로 전환</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="174"/>
        <source>left</source>
        <translation type="finished">왼쪽</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="179"/>
        <source>right</source>
        <translation type="finished">오른쪽</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="184"/>
        <source>up</source>
        <translation type="finished">위</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="189"/>
        <source>down</source>
        <translation type="finished">아래</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="201"/>
        <source>Lock cursor to screen</source>
        <translation type="finished">커서를 화면안에 고정</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="225"/>
        <source>toggle</source>
        <translation type="finished">토글</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="230"/>
        <source>on</source>
        <translation type="finished">켜짐</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="235"/>
        <source>off</source>
        <translation type="finished">꺼짐</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="248"/>
        <source>This action is performed when</source>
        <translation type="finished">이 동작이 수행 될 때:</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="254"/>
        <source>the hotkey is pressed</source>
        <translation type="finished">단축키가 눌렸습니다.</translation>
    </message>
    <message>
        <location filename="res/ActionDialogBase.ui" line="264"/>
        <source>the hotkey is released</source>
        <translation type="finished">단축키가 놓아졌습니다.</translation>
    </message>
</context>
<context>
    <name>HotkeyDialogBase</name>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="14"/>
        <source>Hotkey</source>
        <translation type="finished">단축키</translation>
    </message>
    <message>
        <location filename="res/HotkeyDialogBase.ui" line="20"/>
        <source>Enter the specification for the hotkey:</source>
        <translation type="finished">단축키로 설정할 키를 누르세요:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="src/MainWindow.cpp" line="642"/>
        <source>&amp;Start</source>
        <translation type="finished">시작(&amp;S)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="196"/>
        <source>&amp;File</source>
        <translation type="finished">파일(&amp;F)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="197"/>
        <source>&amp;Edit</source>
        <translation type="finished">편집(&amp;E)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="198"/>
        <source>&amp;Window</source>
        <translation type="finished">창(&amp;W)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="199"/>
        <source>&amp;Help</source>
        <translation type="finished">도움말(&amp;H)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="326"/>
        <source>&lt;p&gt;Version %1 is now available, &lt;a href=&quot;%2&quot;&gt;visit website&lt;/a&gt;.&lt;/p&gt;</source>
        <translation type="finished">&lt;p&gt;%1버전이 사용 가능합니다.&lt;a href=&quot;%2&quot;&gt;홈페이지 가기&lt;/a&gt;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="458"/>
        <source>Program can not be started</source>
        <translation type="finished">프로그램을 시작할 수 없습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="458"/>
        <source>The executable&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;could not be successfully started, although it does exist. Please check if you have sufficient permissions to run this program.</source>
        <translation type="finished">실행파일&lt;br&gt;&lt;br&gt;%1&lt;br&gt;&lt;br&gt;이(가) 존재하지만 성공적으로 실행되지 못했습니다. 이 프로그램을 실행시키기 위한 충분한 권한을 가지고 있는지 확인해주세요.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="477"/>
        <source>Synergy client not found</source>
        <translation type="finished">Synergy 클라이언트를 찾을 수 없습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="478"/>
        <source>The executable for the synergy client does not exist.</source>
        <translation type="finished">Synergy 클라이언트 실행 파일이 존재하지 않습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="485"/>
        <source>Hostname is empty</source>
        <translation type="finished">호스트명이 비어있습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="486"/>
        <source>Please fill in a hostname for the synergy client to connect to.</source>
        <translation type="finished">클라이언트가 접속할 호스트명을 입력해주세요.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="511"/>
        <source>Cannot write configuration file</source>
        <translation type="finished">설정파일을 쓸 수 없습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="511"/>
        <source>The temporary configuration file required to start synergy can not be written.</source>
        <translation type="finished">Synergy를 구동하기 위해 필요한 임시 설정 파일을 작성할 수 없습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="524"/>
        <source>Configuration filename invalid</source>
        <translation type="finished">설정 파일 이름이 올바르지 않습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="525"/>
        <source>You have not filled in a valid configuration file for the synergy server. Do you want to browse for the configuration file now?</source>
        <translation type="finished">Synergy 서버를 실행하기 위한 설정 파일이 제대로 작성되어 있지 않습니다. 지금 설정 파일을 찾아 보시겠습니까?</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="552"/>
        <source>Synergy server not found</source>
        <translation type="finished">Synergy 서버를 찾을 수 없습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="553"/>
        <source>The executable for the synergy server does not exist.</source>
        <translation type="finished">Synergy 서버 실행 파일이 존재하지 않습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="617"/>
        <source>Synergy terminated with an error</source>
        <translation type="finished">Synergy가 오류로 인해 종료되었습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="617"/>
        <source>Synergy terminated unexpectedly with an exit code of %1.&lt;br&gt;&lt;br&gt;Please see the log output for details.</source>
        <translation type="finished">Synergy가 %1의 코드로 비 정상적으로 종료되었습니다.&lt;br&gt;&lt;br&gt;자세한 사항은 로그 출력결과를 확인하세요</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="636"/>
        <source>&amp;Stop</source>
        <translation type="finished">중지(&amp;S)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="659"/>
        <source>service mode</source>
        <translation type="finished">서비스 모드</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="659"/>
        <source>desktop mode</source>
        <translation type="finished">데스크탑 모드</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="660"/>
        <source>Synergy is running (%1).</source>
        <translation type="finished">Synergy가 실행 중 입니다 (%1).</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="821"/>
        <source>Elevate Synergy</source>
        <translation type="finished">Synergy 승급</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="822"/>
        <source>Are you sure you want to elevate Synergy?

This allows Synergy to interact with elevated processes and the UAC dialog, but can cause problems with non-elevated processes. Elevate Synergy only if you really need to.</source>
        <translation type="finished">Synergy의 권한을 승급 하시겠습니까?
이것을 허용하게 되면 Synergy와 승급된 프로세스, UAC 대화상자와 상호작용 할 수 있지만, 승급되지 않은 프로세스들과 문제가 생길 수 있습니다. Synergy 권한 승급은 반드시 필요한 경우에만 사용하세요.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="664"/>
        <source>Synergy is starting.</source>
        <translation type="finished">Synergy가 실행 중 입니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="667"/>
        <source>Synergy is not running.</source>
        <translation type="finished">Synergy가 실행 중이지 않습니다.</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="724"/>
        <source>Unknown</source>
        <translation type="finished">알수없음</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="762"/>
        <source>Browse for a synergys config file</source>
        <translation type="finished">synergys 설정 파일 탐색</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="775"/>
        <source>Save configuration as...</source>
        <translation type="finished">설정을 다른 이름으로 저장...</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="779"/>
        <source>Save failed</source>
        <translation type="finished">저장에 실패했습니다</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="779"/>
        <source>Could not save configuration to file.</source>
        <translation type="finished">설정 사항을 파일에 저장할 수 없습니다.</translation>
    </message>
</context>
<context>
    <name>MainWindowBase</name>
    <message>
        <location filename="res/MainWindowBase.ui" line="26"/>
        <source>Synergy</source>
        <translation type="finished">Synergy</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="54"/>
        <source>Screen name:</source>
        <translation type="finished">화면 이름:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="61"/>
        <source>&amp;Server IP:</source>
        <translation type="finished">서버 IP:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="160"/>
        <location filename="res/MainWindowBase.ui" line="315"/>
        <source>&amp;Start</source>
        <translation type="finished">시작(&amp;S)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="187"/>
        <source>&amp;Server (share this computer's mouse and keyboard):</source>
        <translation type="finished">서버(&amp;S) (이 컴퓨터의 마우스와 키보드를 공유):</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="254"/>
        <source>Use existing configuration:</source>
        <translation type="finished">기존 설정을 사용:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="263"/>
        <source>&amp;Configuration file:</source>
        <translation type="finished">설정 파일(&amp;C):</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="283"/>
        <source>&amp;Browse...</source>
        <translation type="finished">찾아 보기(&amp;B)...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="220"/>
        <source>Configure interactively:</source>
        <translation type="finished">상호작용 설정:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="232"/>
        <source>&amp;Configure Server...</source>
        <translation type="finished">서버 설정(&amp;C)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="39"/>
        <source>&amp;Client (use another computer's keyboard and mouse):</source>
        <translation type="finished">클라이언트(&amp;C) (다른 컴퓨터의 키보드와 마우스를 사용):</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="84"/>
        <source>Ready</source>
        <translation type="finished">준비</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="91"/>
        <source>Log</source>
        <translation type="finished">로그</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="167"/>
        <source>&amp;Apply</source>
        <translation type="finished">적용(&amp;A)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="174"/>
        <source>&amp;Elevate</source>
        <translation type="finished">올리기</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="204"/>
        <source>IP addresses:</source>
        <translation type="finished">IP 주소:</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="296"/>
        <source>&amp;About Synergy...</source>
        <translation type="finished">Synergy에 관하여(&amp;A)...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="304"/>
        <source>&amp;Quit</source>
        <translation type="finished">종료(&amp;Q)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="307"/>
        <source>Quit</source>
        <translation type="finished">종료</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="318"/>
        <source>Run</source>
        <translation type="finished">실행</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="329"/>
        <source>S&amp;top</source>
        <translation type="finished">중지(&amp;T)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="332"/>
        <source>Stop</source>
        <translation type="finished">중지</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="340"/>
        <source>S&amp;how Status</source>
        <translation type="finished">상태 보기(&amp;H)</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="348"/>
        <source>&amp;Hide</source>
        <translation type="finished">숨기기</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="351"/>
        <source>Hide</source>
        <translation type="finished">숨기기</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="359"/>
        <source>&amp;Show</source>
        <translation type="finished">보이기</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="362"/>
        <source>Show</source>
        <translation type="finished">보이기</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="370"/>
        <source>Save configuration &amp;as...</source>
        <translation type="finished">설정을 다른 이름으로 저장(&amp;A)...</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="373"/>
        <source>Save the interactively generated server configuration to a file.</source>
        <translation type="finished">상호작용으로 생성된 서버 설정을 파일로 저장하기.</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="381"/>
        <source>Settings</source>
        <translation type="finished">설정</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="384"/>
        <source>Edit settings</source>
        <translation type="finished">설정 편집</translation>
    </message>
    <message>
        <location filename="res/MainWindowBase.ui" line="392"/>
        <source>Run Wizard</source>
        <translation type="finished">마법사 실행</translation>
    </message>
</context>
<context>
    <name>NewScreenWidget</name>
    <message>
        <location filename="src/NewScreenWidget.cpp" line="32"/>
        <source>Unnamed</source>
        <translation type="finished">이름없음</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="src/MainWindow.cpp" line="45"/>
        <source>Synergy Configurations (*.sgc);;All files (*.*)</source>
        <translation type="finished">Synergy 설정파일 (*.sgc);;모든 파일 (*.*)</translation>
    </message>
    <message>
        <location filename="src/MainWindow.cpp" line="48"/>
        <source>Synergy Configurations (*.conf);;All files (*.*)</source>
        <translation type="finished">Synergy 설정파일 (*.conf);;모든 파일 (*.*)</translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="90"/>
        <source>System tray is unavailable, quitting.</source>
        <translation type="finished">시스템 트레이를 사용할 수 없어 종료합니다.</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialog</name>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="65"/>
        <source>Screen name is empty</source>
        <translation type="finished">스크린 이름이 비었습니다</translation>
    </message>
    <message>
        <location filename="src/ScreenSettingsDialog.cpp" line="65"/>
        <source>The name for a screen can not be empty. Please fill in a name or cancel the dialog.</source>
        <translation type="finished">스크린 이름이 비었습니다. 이름을 입력하거나 입력창을 취소하세요.</translation>
    </message>
</context>
<context>
    <name>ScreenSettingsDialogBase</name>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="14"/>
        <source>Screen Settings</source>
        <translation type="finished">화면 설정</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="22"/>
        <source>Screen &amp;name:</source>
        <translation type="finished">화면 이름(&amp;N):</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="42"/>
        <source>A&amp;liases</source>
        <translation type="finished">별칭(&amp;L)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="57"/>
        <source>&amp;Add</source>
        <translation type="finished">추가(&amp;A)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="74"/>
        <source>&amp;Remove</source>
        <translation type="finished">삭제(&amp;R)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="97"/>
        <source>&amp;Modifier keys</source>
        <translation type="finished">보조 키(&amp;M)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="106"/>
        <source>&amp;Shift:</source>
        <translation type="finished">&amp;Shift:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="117"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="164"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="211"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="258"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="305"/>
        <source>Shift</source>
        <translation type="finished">Shift</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="122"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="169"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="216"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="263"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="310"/>
        <source>Ctrl</source>
        <translation type="finished">Ctrl</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="127"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="174"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="221"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="268"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="315"/>
        <source>Alt</source>
        <translation type="finished">Alt</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="132"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="179"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="226"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="273"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="320"/>
        <source>Meta</source>
        <translation type="finished">메타</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="137"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="184"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="231"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="278"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="325"/>
        <source>Super</source>
        <translation type="finished">슈퍼</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="142"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="189"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="236"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="283"/>
        <location filename="res/ScreenSettingsDialogBase.ui" line="330"/>
        <source>None</source>
        <translation type="finished">없음</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="150"/>
        <source>&amp;Ctrl:</source>
        <translation type="finished">&amp;Ctrl:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="197"/>
        <source>Al&amp;t:</source>
        <translation type="finished">Al&amp;t:</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="244"/>
        <source>M&amp;eta:</source>
        <translation type="finished">메타(&amp;M):</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="291"/>
        <source>S&amp;uper:</source>
        <translation type="finished">슈퍼(&amp;U):</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="358"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">사용하지 않는 모서리(&amp;D)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="367"/>
        <source>Top-left</source>
        <translation type="finished">상단 왼쪽</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="374"/>
        <source>Top-right</source>
        <translation type="finished">상단 오른쪽</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="381"/>
        <source>Bottom-left</source>
        <translation type="finished">하단 왼쪽</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="388"/>
        <source>Bottom-right</source>
        <translation type="finished">하단 오른쪽</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="397"/>
        <source>Corner Si&amp;ze:</source>
        <translation type="finished">모서리 크기(&amp;Z)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="428"/>
        <source>&amp;Fixes</source>
        <translation type="finished">고정(&amp;F)</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="437"/>
        <source>Fix CAPS LOCK key</source>
        <translation type="finished">CAPS LOCK 키 고정</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="444"/>
        <source>Fix NUM LOCK key</source>
        <translation type="finished">NUM LOCK 키 고정</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="451"/>
        <source>Fix SCROLL LOCK key</source>
        <translation type="finished">SCROLL LOCK 키 고정</translation>
    </message>
    <message>
        <location filename="res/ScreenSettingsDialogBase.ui" line="458"/>
        <source>Fix XTest for Xinerama</source>
        <translation type="finished">Xinerama를 위한 XTest 고정</translation>
    </message>
</context>
<context>
    <name>ScreenSetupModel</name>
    <message>
        <location filename="src/ScreenSetupModel.cpp" line="51"/>
        <source>&lt;center&gt;Screen: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;Double click to edit settings&lt;br&gt;Drag screen to the trashcan to remove it</source>
        <translation type="finished">&lt;center&gt;화면: &lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;&lt;br&gt;설정을 편집하려면 더블클릭&lt;br&gt;삭제하려면 휴지통으로 드래그 하세요</translation>
    </message>
</context>
<context>
    <name>ServerConfigDialogBase</name>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="13"/>
        <source>Server Configuration</source>
        <translation type="finished">서버 설정</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="23"/>
        <source>Screens and links</source>
        <translation type="finished">화면과 링크</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="34"/>
        <source>Drag a screen from the grid to the trashcan to remove it.</source>
        <translation type="finished">삭제하려면 화면을 휴지통으로 드래그 하세요.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="59"/>
        <source>Configure the layout of your synergy server configuration.</source>
        <translation type="finished">Synergy 서버 구성과 레이아웃을 설정하세요.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="72"/>
        <source>Drag this button to the grid to add a new screen.</source>
        <translation type="finished">새로운 화면을 추가하려면 이 버튼을 격자 안으로 드래그 하세요.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="127"/>
        <source>Drag new screens to the grid or move existing ones around.
Drag a screen to the trashcan to delete it.
Double click on a screen to edit its settings.</source>
        <translation type="finished">새로운 화면을 추가하려면 상단의 화면을 격자 안으로 드래그 하세요.
화면을 삭제하려면 휴지통으로 드래그 하세요.
화면 설정을 편집하려면 더블클릭 하세요.</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="156"/>
        <source>Hotkeys</source>
        <translation type="finished">단축키</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="162"/>
        <source>&amp;Hotkeys</source>
        <translation type="finished">단축키(&amp;H)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="174"/>
        <source>&amp;New</source>
        <translation type="finished">생성(&amp;N)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="184"/>
        <source>&amp;Edit</source>
        <translation type="finished">편집(&amp;E)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="194"/>
        <source>&amp;Remove</source>
        <translation type="finished">삭제(&amp;R)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="217"/>
        <source>A&amp;ctions</source>
        <translation type="finished">행동(&amp;C)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="229"/>
        <source>Ne&amp;w</source>
        <translation type="finished">생성(&amp;W)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="239"/>
        <source>E&amp;dit</source>
        <translation type="finished">편집(&amp;D)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="249"/>
        <source>Re&amp;move</source>
        <translation type="finished">삭제(&amp;M)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="273"/>
        <source>Advanced server settings</source>
        <translation type="finished">고급 설정</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="279"/>
        <source>&amp;Switch</source>
        <translation type="finished">전환(&amp;S)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="290"/>
        <source>Switch &amp;after waiting</source>
        <translation type="finished">대기 후 전환(&amp;A)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="329"/>
        <location filename="res/ServerConfigDialogBase.ui" line="382"/>
        <location filename="res/ServerConfigDialogBase.ui" line="457"/>
        <source>ms</source>
        <translation type="finished">ms</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="343"/>
        <source>Switch on double &amp;tap within</source>
        <translation type="finished">지정시간 안에 더블 탭으로 전환(&amp;T)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="407"/>
        <source>&amp;Options</source>
        <translation type="finished">옵션(&amp;O)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="418"/>
        <source>&amp;Check clients every</source>
        <translation type="finished">지정 시간마다 클라이언트 확인(&amp;C)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="469"/>
        <source>Use &amp;relative mouse moves</source>
        <translation type="finished">상대적인 마우스 이동 사용(&amp;R)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="479"/>
        <source>S&amp;ynchronize screen savers</source>
        <translation type="finished">스크린세이버 동기화(&amp;Y)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="489"/>
        <source>Don't take &amp;foreground window on Windows servers</source>
        <translation type="finished">클라이언트로 전환시해도 서버의 포커스 방지 (전체화면 작업중 클라이언트로 전환해도 전체화면이 유지되며, 서버에서 전체화면 중 최소화 후 클라이언트 전환시 전체화면을 방지)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="512"/>
        <source>&amp;Dead corners</source>
        <translation type="finished">사용하지 않는 모서리(&amp;D)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="521"/>
        <source>To&amp;p-left</source>
        <translation type="finished">상단 왼쪽(&amp;P)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="528"/>
        <source>Top-rig&amp;ht</source>
        <translation type="finished">상단 오른쪽(&amp;H)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="535"/>
        <source>&amp;Bottom-left</source>
        <translation type="finished">하단 왼쪽(&amp;B)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="542"/>
        <source>Bottom-ri&amp;ght</source>
        <translation type="finished">하단 오른쪽(&amp;G)</translation>
    </message>
    <message>
        <location filename="res/ServerConfigDialogBase.ui" line="564"/>
        <source>Cor&amp;ner Size:</source>
        <translation type="finished">모서리 크기(&amp;N):</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="src/SettingsDialog.cpp" line="62"/>
        <source>Encryption password must not be empty.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/SettingsDialog.cpp" line="121"/>
        <source>Save log file to...</source>
        <translation type="finished">로그 파일 저장하기...</translation>
    </message>
</context>
<context>
    <name>SettingsDialogBase</name>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="14"/>
        <source>Settings</source>
        <translation type="finished">설정</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="165"/>
        <source>&amp;Advanced</source>
        <translation type="finished">고급(&amp;A)</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="177"/>
        <source>Sc&amp;reen name:</source>
        <translation type="finished">화면 이름(&amp;R):</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="194"/>
        <source>P&amp;ort:</source>
        <translation type="finished">포트(&amp;O):</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="223"/>
        <source>&amp;Interface:</source>
        <translation type="finished">인터페이스(&amp;I):</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="26"/>
        <source>&amp;Start Synergy after logging in</source>
        <translation type="finished">윈도우 시작시 Synergy 시작(&amp;S)</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="33"/>
        <source>&amp;Automatically start server/client</source>
        <translation type="finished">서버/클라이언트를 자동으로 시작(&amp;A)</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="40"/>
        <source>&amp;Hide when server/client starts</source>
        <translation type="finished">서버/클라이언트가 시작되면 숨기기(&amp;H)</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="273"/>
        <source>Logging</source>
        <translation type="finished">로그 기록</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="240"/>
        <source>&amp;Process mode:</source>
        <translation type="finished">프로세스 모드:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="251"/>
        <source>Service</source>
        <translation type="finished">서비스</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="256"/>
        <source>Desktop (legacy)</source>
        <translation type="finished">데스크탑 (레거시)</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="291"/>
        <source>&amp;Logging level:</source>
        <translation type="finished">기록 수준(&amp;L):</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="340"/>
        <source>Log to file:</source>
        <translation type="finished">파일로 저장:</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="357"/>
        <source>Browse...</source>
        <translation type="finished">찾아보기...</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="302"/>
        <source>Error</source>
        <translation type="finished">오류</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="20"/>
        <source>&amp;Graphical interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="55"/>
        <source>&amp;Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="82"/>
        <source>&amp;Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="97"/>
        <source>&amp;Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="142"/>
        <source>Pass&amp;word:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="307"/>
        <source>Warning</source>
        <translation type="finished">경고</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="312"/>
        <source>Note</source>
        <translation type="finished">알림</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="317"/>
        <source>Info</source>
        <translation type="finished">정보</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="322"/>
        <source>Debug</source>
        <translation type="finished">디버그</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="327"/>
        <source>Debug1</source>
        <translation type="finished">디버그1</translation>
    </message>
    <message>
        <location filename="res/SettingsDialogBase.ui" line="332"/>
        <source>Debug2</source>
        <translation type="finished">디버그2</translation>
    </message>
</context>
<context>
    <name>SetupWizard</name>
    <message>
        <location filename="src/SetupWizard.cpp" line="64"/>
        <source>Setup Synergy</source>
        <translation type="finished">시너지 설정</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="74"/>
        <source>Please select an option.</source>
        <translation type="finished">옵션을 선택하세요.</translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="84"/>
        <source>Encryption mode required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="93"/>
        <source>Encryption password required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/SetupWizard.cpp" line="100"/>
        <source>Encryption password and confirmation do not match.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetupWizardBase</name>
    <message>
        <location filename="res/SetupWizardBase.ui" line="20"/>
        <source>Setup Synergy</source>
        <translation type="finished">시너지 설정</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="24"/>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="33"/>
        <source>Thanks for installing Synergy!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="108"/>
        <source>Synergy lets you easily share your mouse and keyboard between multiple computers on your desk, and it's Free and Open Source. Just move your mouse off the edge of one computer's screen on to another. You can even share all of your clipboards. All you need is a network connection. Synergy is cross-platform (works on Windows, Mac OS X and Linux).</source>
        <translation type="finished">Synergy는 마우스와 키보드를  여러 컴퓨터에 쉽게 공유하여 사용할 수 있게 해주는 무료 오픈 소스 프로그램입니다. 마우스를 한쪽 컴퓨터의 화면 끝으로 옮기기만 하면 다른 컴퓨터의 화면으로 이동할 수 있으며 클립보드의 내용까지도 공유할 수 있습니다. 필요한 것은 단지 네트워크 연결 뿐이며 Synergy는 여러 플랫폼(Windows와 Mac OS X, Linux)에서 사용할 수 있습니다. </translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="125"/>
        <source>Server or Client?</source>
        <translation type="finished">서버 또는 클라이언트?</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="140"/>
        <source>&amp;Server (new setup)</source>
        <translation type="finished">서버(&amp;S) (신규 설정)</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="153"/>
        <source>This is the first computer you are configuring. Your keyboard and mouse are connected to this computer. This will allow you to move your mouse over to another computer's screen. There can only be one server in your setup.</source>
        <translation type="finished">여러분이 설정하는 첫 컴퓨터입니다. 여러분의 키보드와 마우스는 이 컴퓨터에 연결되어 있으며, 여기에 연결된 마우스를 다른 컴퓨터의 화면으로 옮겨다닐 수 있게 됩니다. Synergy 환경을 구성할 때 서버는 하나만 존재해야 합니다.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="185"/>
        <source>&amp;Client (add to setup)</source>
        <translation type="finished">클라이언트(&amp;C) (기존 Synergy환경에 추가)</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="198"/>
        <source>You have already set up a server. This is a computer you wish to control using the server's keyboard and mouse. There can be many clients in your setup.</source>
        <oldsource>You have already set up a server. This a computer you wish to control using the server's keyboard and mouse. There can be many clients in your setup.</oldsource>
        <translation type="finished">이미 서버 하나를 설정해 두었습니다. 이 컴퓨터는 서버의 키보드와 마우스를 사용해서 조작할 수 있게 됩니다. Synergy 환경에 여러개의 클라이언트를 추가할 수 있습니다.</translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="231"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="237"/>
        <source>Network traffic can be easily monitored. Using encryption can reduce the risk that sensitive information will be revealed to others (for example, passwords).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="263"/>
        <source>Choose a random encryption mode. The mode must be the same on both the client and server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="308"/>
        <source>&amp;Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="391"/>
        <source>A longer password will provide stronger encryption. It is a good idea to use 20 characters or more.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="415"/>
        <source>&amp;Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="res/SetupWizardBase.ui" line="474"/>
        <source>&amp;Confirm:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VersionChecker</name>
    <message>
        <location filename="src/VersionChecker.cpp" line="102"/>
        <source>Unknown</source>
        <translation type="finished">알수없음</translation>
    </message>
</context>
</TS>